-- Enable UUID extension if not enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  username text NOT NULL UNIQUE,
  password text NOT NULL,
  created_at timestamp DEFAULT now() NOT NULL
);

-- Create verification_sessions table
CREATE TABLE IF NOT EXISTS verification_sessions (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id varchar REFERENCES users(id) NOT NULL,
  name text NOT NULL,
  status text NOT NULL,
  total_cards integer DEFAULT 0,
  processed_cards integer DEFAULT 0,
  valid_cards integer DEFAULT 0,
  invalid_cards integer DEFAULT 0,
  error_cards integer DEFAULT 0,
  checker_type text NOT NULL,
  settings jsonb,
  created_at timestamp DEFAULT now() NOT NULL,
  started_at timestamp,
  completed_at timestamp
);

-- Create cards table (without CVV storage per PCI DSS)
CREATE TABLE IF NOT EXISTS cards (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id varchar REFERENCES verification_sessions(id) NOT NULL,
  card_number_hash text NOT NULL,
  card_number_masked text NOT NULL,
  expiry_month varchar(2),
  expiry_year varchar(4),
  status text DEFAULT 'pending',
  created_at timestamp DEFAULT now() NOT NULL
);

-- Create verification_results table
CREATE TABLE IF NOT EXISTS verification_results (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  card_id varchar REFERENCES cards(id) NOT NULL,
  session_id varchar REFERENCES verification_sessions(id) NOT NULL,
  checker_type text NOT NULL,
  status text NOT NULL,
  response text,
  response_code text,
  processing_time_ms integer,
  gateway_info jsonb,
  created_at timestamp DEFAULT now() NOT NULL
);

-- Create checker_configs table
CREATE TABLE IF NOT EXISTS checker_configs (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  checker_type text NOT NULL UNIQUE,
  is_enabled boolean DEFAULT true,
  max_concurrent integer DEFAULT 10,
  rate_limit integer DEFAULT 100,
  timeout integer DEFAULT 5000,
  settings jsonb,
  last_updated timestamp DEFAULT now() NOT NULL
);

-- Create audit_logs table
CREATE TABLE IF NOT EXISTS audit_logs (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id varchar REFERENCES users(id),
  action text NOT NULL,
  resource_type text NOT NULL,
  resource_id varchar,
  details jsonb,
  ip_address text,
  user_agent text,
  created_at timestamp DEFAULT now() NOT NULL
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_verification_sessions_user_id ON verification_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_cards_session_id ON cards(session_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_session_id ON verification_results(session_id);
CREATE INDEX IF NOT EXISTS idx_verification_results_card_id ON verification_results(card_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);

-- Add unique constraint to prevent duplicate cards per session
CREATE UNIQUE INDEX IF NOT EXISTS idx_cards_session_hash ON cards(session_id, card_number_hash);

-- Insert default checker configurations
INSERT INTO checker_configs (checker_type, is_enabled, max_concurrent, rate_limit, timeout, settings) VALUES
('luna', true, 10, 100, 5000, '{}'),
('orio', true, 8, 80, 6000, '{}'),
('ady', true, 15, 150, 4000, '{}'),
('manzana', true, 12, 120, 5500, '{}'),
('stritt', true, 5, 50, 8000, '{}')
ON CONFLICT (checker_type) DO NOTHING;
