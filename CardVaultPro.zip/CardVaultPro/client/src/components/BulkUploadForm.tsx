import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Upload, FileText, X, CheckCircle, AlertCircle } from "lucide-react";
import { useState, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface BulkUploadFormProps {
  onUpload?: (cards: any[]) => void;
}

export default function BulkUploadForm({ onUpload }: BulkUploadFormProps) {
  const [uploadMethod, setUploadMethod] = useState<'file' | 'paste'>('file');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [textInput, setTextInput] = useState('');
  const [validationStats, setValidationStats] = useState<{
    total: number;
    valid: number;
    invalid: number;
  } | null>(null);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleFileUpload = (files: FileList | null) => {
    if (!files) return;
    
    const newFiles = Array.from(files).filter(file => 
      file.type === 'text/csv' || 
      file.type === 'text/plain' || 
      file.name.endsWith('.txt') || 
      file.name.endsWith('.csv')
    );
    
    setUploadedFiles(prev => [...prev, ...newFiles]);
    console.log('Files uploaded:', newFiles.map(f => f.name));
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (data: { name: string; checkerType: string }) => {
      const response = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Failed to create session');
      return response.json();
    },
    onError: (error: any) => {
      toast({
        title: "Session Creation Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Bulk upload mutation
  const bulkUploadMutation = useMutation({
    mutationFn: async (data: { sessionId: string; cards: any[] }) => {
      const response = await fetch(`/api/sessions/${data.sessionId}/cards/bulk`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cards: data.cards })
      });
      if (!response.ok) throw new Error('Failed to upload cards');
      return response.json();
    },
    onSuccess: (data) => {
      setValidationStats({
        total: data.created + data.failed,
        valid: data.created,
        invalid: data.failed
      });
      toast({
        title: "Upload Complete",
        description: `Processed ${data.created + data.failed} cards successfully`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
    },
    onError: (error: any) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const parseCardData = (text: string) => {
    const lines = text.trim().split('\n').filter(line => line.trim());
    const cards: any[] = [];
    
    for (const line of lines) {
      const parts = line.split(/[,|\t]/).map(p => p.trim());
      if (parts.length >= 3) {
        cards.push({
          cardNumber: parts[0],
          expiryMonth: parts[1]?.padStart(2, '0'),
          expiryYear: parts[2]?.length === 2 ? '20' + parts[2] : parts[2]
        });
      }
    }
    
    return cards;
  };

  const handleBulkProcess = async () => {
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Step 1: Create session
      setUploadProgress(10);
      const session = await createSessionMutation.mutateAsync({
        name: `Bulk Upload ${new Date().toLocaleString()}`,
        checkerType: 'luna'
      });
      
      setCurrentSessionId(session.id);
      setUploadProgress(25);

      // Step 2: Parse card data
      let cards: any[] = [];
      
      if (uploadMethod === 'paste' && textInput.trim()) {
        cards = parseCardData(textInput);
      } else if (uploadMethod === 'file' && uploadedFiles.length > 0) {
        // For file upload, we'd need to read the files
        const fileReader = new FileReader();
        const file = uploadedFiles[0];
        
        await new Promise<void>((resolve, reject) => {
          fileReader.onload = (e) => {
            const content = e.target?.result as string;
            cards = parseCardData(content);
            resolve();
          };
          fileReader.onerror = reject;
          fileReader.readAsText(file);
        });
      }
      
      setUploadProgress(50);
      
      if (cards.length === 0) {
        throw new Error('No valid card data found');
      }

      // Step 3: Upload cards
      await bulkUploadMutation.mutateAsync({
        sessionId: session.id,
        cards: cards
      });
      
      setUploadProgress(100);

      if (onUpload) {
        onUpload(cards);
      }

    } catch (error: any) {
      toast({
        title: "Processing Failed",
        description: error.message || "Failed to process cards",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2" data-testid="text-upload-title">
          <Upload className="w-5 h-5" />
          Bulk Card Upload
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Upload card data via CSV/TXT files or paste directly. Format: CardNumber,MM,YY,CVV
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Upload Method Selection */}
        <div className="flex gap-2">
          <Button 
            variant={uploadMethod === 'file' ? 'default' : 'outline'}
            onClick={() => setUploadMethod('file')}
            size="sm"
            data-testid="button-file-method"
          >
            <FileText className="w-4 h-4 mr-2" />
            File Upload
          </Button>
          <Button 
            variant={uploadMethod === 'paste' ? 'default' : 'outline'}
            onClick={() => setUploadMethod('paste')}
            size="sm"
            data-testid="button-paste-method"
          >
            <Upload className="w-4 h-4 mr-2" />
            Paste Text
          </Button>
        </div>

        {/* File Upload Method */}
        {uploadMethod === 'file' && (
          <div className="space-y-4">
            <div 
              className="border-2 border-dashed border-border rounded-lg p-8 text-center hover-elevate cursor-pointer transition-colors"
              onClick={() => fileInputRef.current?.click()}
              onDrop={(e) => {
                e.preventDefault();
                handleFileUpload(e.dataTransfer.files);
              }}
              onDragOver={(e) => e.preventDefault()}
              data-testid="dropzone-upload"
            >
              <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-lg font-medium mb-2">Drop files here or click to browse</p>
              <p className="text-sm text-muted-foreground">
                Supports CSV and TXT files • Max 10MB per file
              </p>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".csv,.txt"
                className="hidden"
                onChange={(e) => handleFileUpload(e.target.files)}
                data-testid="input-file-upload"
              />
            </div>

            {/* Uploaded Files List */}
            {uploadedFiles.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Uploaded Files:</h4>
                {uploadedFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg" data-testid={`file-item-${index}`}>
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-primary" />
                      <div>
                        <p className="text-sm font-medium">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                      </div>
                    </div>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      onClick={() => removeFile(index)}
                      data-testid={`button-remove-file-${index}`}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Paste Text Method */}
        {uploadMethod === 'paste' && (
          <div className="space-y-4">
            <Textarea
              placeholder="Paste your card data here, one per line:\n4532123456781234,12,25,123\n5555987654321234,08,26,456\n4111111111111111,03,27,789"
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              rows={10}
              className="font-mono text-sm"
              data-testid="textarea-paste-input"
            />
            <p className="text-xs text-muted-foreground">
              Format: CardNumber,MM,YY,CVV (one per line)
            </p>
          </div>
        )}

        {/* Upload Progress */}
        {isUploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Processing cards...</span>
              <span className="font-mono font-medium" data-testid="text-upload-progress">{Math.round(uploadProgress)}%</span>
            </div>
            <Progress value={uploadProgress} className="h-2" data-testid="progress-upload" />
          </div>
        )}

        {/* Validation Stats */}
        {validationStats && (
          <div className="grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
            <div className="text-center">
              <div className="text-lg font-bold font-mono" data-testid="text-stats-total">{validationStats.total.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground">Total Cards</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold font-mono text-chart-2" data-testid="text-stats-valid">{validationStats.valid.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground">Valid Format</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold font-mono text-destructive" data-testid="text-stats-invalid">{validationStats.invalid.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground">Invalid Format</div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pt-4 border-t">
          <Button 
            onClick={handleBulkProcess}
            disabled={isUploading || (uploadedFiles.length === 0 && !textInput.trim())}
            className="flex-1"
            data-testid="button-process-bulk"
          >
            {isUploading ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full mr-2" />
                Processing...
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Process Cards
              </>
            )}
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => {
              setUploadedFiles([]);
              setTextInput('');
              setValidationStats(null);
              setUploadProgress(0);
            }}
            disabled={isUploading}
            data-testid="button-clear-all"
          >
            Clear All
          </Button>
        </div>

        {/* Format Help */}
        <div className="text-xs text-muted-foreground border-t pt-4">
          <p className="font-medium mb-1">Supported formats:</p>
          <ul className="space-y-1">
            <li>• CSV: 4532123456781234,12,25,123</li>
            <li>• Pipe separated: 4532123456781234|12|25|123</li>
            <li>• Tab separated: 4532123456781234       12      25      123</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}