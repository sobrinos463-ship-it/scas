import { AppSidebar } from '../AppSidebar';

export default function AppSidebarExample() {
  return (
    <div className="h-screen w-64">
      <AppSidebar />
    </div>
  );
}