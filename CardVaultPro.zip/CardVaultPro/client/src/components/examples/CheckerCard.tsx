import CheckerCard from '../CheckerCard';
import { Moon, Zap, Shield, Apple, CreditCard } from 'lucide-react';

export default function CheckerCardExample() {
  //todo: remove mock functionality
  const handleAction = (action: string, checker: string) => {
    console.log(`${action} triggered for ${checker}`);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      <CheckerCard
        name="LUNA"
        description="High-precision Luhn validator with advanced pattern recognition"
        icon={<Moon className="w-5 h-5" />}
        status="running"
        progress={67}
        stats={{
          total: 15420,
          valid: 8934,
          invalid: 4521,
          pending: 1965
        }}
        onStart={() => handleAction('Start', 'LUNA')}
        onPause={() => handleAction('Pause', 'LUNA')}
        onConfigure={() => handleAction('Configure', 'LUNA')}
        onViewResults={() => handleAction('View Results', 'LUNA')}
      />
      
      <CheckerCard
        name="ORIO"
        description="Multi-gateway processor with real-time verification"
        icon={<Zap className="w-5 h-5" />}
        status="idle"
        stats={{
          total: 0,
          valid: 0,
          invalid: 0,
          pending: 0
        }}
        onStart={() => handleAction('Start', 'ORIO')}
        onPause={() => handleAction('Pause', 'ORIO')}
        onConfigure={() => handleAction('Configure', 'ORIO')}
        onViewResults={() => handleAction('View Results', 'ORIO')}
      />
      
      <CheckerCard
        name="ADY"
        description="Lightning-fast bulk validator with optimized algorithms"
        icon={<Shield className="w-5 h-5" />}
        status="completed"
        stats={{
          total: 25600,
          valid: 18234,
          invalid: 7366,
          pending: 0
        }}
        onStart={() => handleAction('Start', 'ADY')}
        onPause={() => handleAction('Pause', 'ADY')}
        onConfigure={() => handleAction('Configure', 'ADY')}
        onViewResults={() => handleAction('View Results', 'ADY')}
      />
      
      <CheckerCard
        name="MANZANA"
        description="Advanced BIN analysis with comprehensive fraud detection"
        icon={<Apple className="w-5 h-5" />}
        status="paused"
        progress={23}
        stats={{
          total: 8750,
          valid: 1456,
          invalid: 823,
          pending: 6471
        }}
        onStart={() => handleAction('Start', 'MANZANA')}
        onPause={() => handleAction('Pause', 'MANZANA')}
        onConfigure={() => handleAction('Configure', 'MANZANA')}
        onViewResults={() => handleAction('View Results', 'MANZANA')}
      />
      
      <CheckerCard
        name="STRITT"
        description="Military-grade security with enterprise-level precision"
        icon={<CreditCard className="w-5 h-5" />}
        status="running"
        progress={89}
        stats={{
          total: 12340,
          valid: 9876,
          invalid: 2340,
          pending: 124
        }}
        onStart={() => handleAction('Start', 'STRITT')}
        onPause={() => handleAction('Pause', 'STRITT')}
        onConfigure={() => handleAction('Configure', 'STRITT')}
        onViewResults={() => handleAction('View Results', 'STRITT')}
      />
    </div>
  );
}