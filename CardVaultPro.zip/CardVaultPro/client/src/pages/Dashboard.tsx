export default function Dashboard() {
  return (
    <div className="p-6 space-y-8" data-testid="page-dashboard">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          Dashboard limpio - listo para tu configuración
        </p>
      </div>
      
      <div className="text-center py-12">
        <p className="text-lg text-muted-foreground">
          Dashboard vacío - Configura tus checkers aquí
        </p>
      </div>
    </div>
  );
}