import CheckerPage from "@/components/CheckerPage";
import { Zap } from "lucide-react";

export default function Orio() {
  return (
    <CheckerPage
      name="ORIO"
      description="Multi-gateway processor with real-time verification"
      icon={<Zap className="w-6 h-6 text-white" />}
      color="bg-yellow-600"
      features={[
        "Multi Gateway",
        "Real-time API",
        "Load Balancing",
        "Instant Results"
      ]}
      defaultConfig={{
        speed: 'fast',
        batchSize: 50,
        skipInvalid: true,
        autoRetry: true,
        timeout: 15
      }}
    />
  );
}