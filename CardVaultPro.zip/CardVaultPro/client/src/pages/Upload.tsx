import BulkUploadForm from "@/components/BulkUploadForm";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Download, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function Upload() {
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleDownloadTemplate = () => {
    // Generate and download CSV template
    const csvTemplate = 'CardNumber,ExpiryMonth,ExpiryYear,CVV\n4532123456781234,12,25,123\n5555987654321234,08,26,456\n4111111111111111,03,27,789';
    const blob = new Blob([csvTemplate], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'card_template.csv';
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Template Downloaded",
      description: "CSV template has been downloaded to your device"
    });
  };

  const handleViewHistory = () => {
    navigate('/results');
    toast({
      title: "Redirecting", 
      description: "Opening verification results page"
    });
  };
  return (
    <div className="p-6 space-y-8" data-testid="page-upload">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Bulk Upload</h1>
        <p className="text-muted-foreground">
          Upload and process large batches of credit card data for verification
        </p>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap items-center gap-4">
        <Button variant="outline" onClick={handleDownloadTemplate} data-testid="button-download-template">
          <Download className="w-4 h-4 mr-2" />
          Download CSV Template
        </Button>
        <Button variant="outline" onClick={handleViewHistory} data-testid="button-view-history">
          <FileText className="w-4 h-4 mr-2" />
          View Upload History
        </Button>
      </div>

      {/* Security Warning */}
      <Card className="border-destructive/20 bg-destructive/5">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-destructive mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-medium text-destructive">Security Notice</h4>
              <p className="text-sm text-muted-foreground">
                Ensure all card data is properly encrypted and comes from authorized sources. 
                This platform is intended for legitimate verification purposes only.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upload Form */}
      <BulkUploadForm />

      {/* Processing Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Processing Guidelines</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-2">Data Requirements</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Valid 16-digit card numbers</li>
                <li>• Expiry dates (MM/YY format)</li>
                <li>• 3-4 digit CVV codes</li>
                <li>• Maximum 50,000 cards per batch</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Processing Limits</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Rate limit: 100 requests/second</li>
                <li>• Concurrent batches: 5 maximum</li>
                <li>• Daily limit: 1M verifications</li>
                <li>• File size: 10MB maximum</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}