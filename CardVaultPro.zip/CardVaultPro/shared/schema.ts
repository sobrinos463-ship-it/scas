import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - authentication and authorization
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Verification sessions for bulk operations
export const verificationSessions = pgTable("verification_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  status: text("status").notNull(), // 'pending', 'running', 'completed', 'failed', 'paused'
  totalCards: integer("total_cards").default(0),
  processedCards: integer("processed_cards").default(0),
  validCards: integer("valid_cards").default(0),
  invalidCards: integer("invalid_cards").default(0),
  errorCards: integer("error_cards").default(0),
  checkerType: text("checker_type").notNull(), // 'luna', 'orio', 'ady', 'manzana', 'stritt'
  settings: json("settings"), // checker-specific settings
  createdAt: timestamp("created_at").defaultNow().notNull(),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
});

// Cards table - stores card data (encrypted/hashed for security)
export const cards = pgTable("cards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => verificationSessions.id).notNull(),
  cardNumberHash: text("card_number_hash").notNull(), // HMAC-SHA256 hash of card number
  cardNumberMasked: text("card_number_masked").notNull(), // e.g., "4532************1234"
  expiryMonth: varchar("expiry_month", { length: 2 }),
  expiryYear: varchar("expiry_year", { length: 4 }), // Use 4 digits to avoid ambiguity
  status: text("status").default('pending'), // 'pending', 'processing', 'verified'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Verification results for individual cards
export const verificationResults = pgTable("verification_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cardId: varchar("card_id").references(() => cards.id).notNull(),
  sessionId: varchar("session_id").references(() => verificationSessions.id).notNull(),
  checkerType: text("checker_type").notNull(),
  status: text("status").notNull(), // 'LIVE', 'DEAD', 'ERROR', 'TIMEOUT'
  response: text("response"), // checker response message
  responseCode: text("response_code"), // standardized response code
  processingTimeMs: integer("processing_time_ms"),
  gatewayInfo: json("gateway_info"), // additional gateway information
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Checker configurations
export const checkerConfigs = pgTable("checker_configs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  checkerType: text("checker_type").notNull().unique(),
  isEnabled: boolean("is_enabled").default(true),
  maxConcurrent: integer("max_concurrent").default(10),
  rateLimit: integer("rate_limit").default(100), // requests per minute
  timeout: integer("timeout").default(5000), // timeout in ms
  settings: json("settings"), // checker-specific configuration
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Audit logs for security and compliance
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  action: text("action").notNull(),
  resourceType: text("resource_type").notNull(),
  resourceId: varchar("resource_id"),
  details: json("details"), // non-sensitive operation details
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertVerificationSessionSchema = createInsertSchema(verificationSessions).pick({
  name: true,
  checkerType: true,
  settings: true,
});

export const insertCardSchema = createInsertSchema(cards).pick({
  sessionId: true,
  cardNumberMasked: true,
  expiryMonth: true,
  expiryYear: true,
});

export const insertVerificationResultSchema = createInsertSchema(verificationResults).pick({
  cardId: true,
  sessionId: true,
  checkerType: true,
  status: true,
  response: true,
  responseCode: true,
  processingTimeMs: true,
  gatewayInfo: true,
});

export const insertCheckerConfigSchema = createInsertSchema(checkerConfigs).pick({
  checkerType: true,
  isEnabled: true,
  maxConcurrent: true,
  rateLimit: true,
  timeout: true,
  settings: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).pick({
  action: true,
  resourceType: true,
  resourceId: true,
  details: true,
  ipAddress: true,
  userAgent: true,
});

// Type definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertVerificationSession = z.infer<typeof insertVerificationSessionSchema>;
export type VerificationSession = typeof verificationSessions.$inferSelect;

export type InsertCard = z.infer<typeof insertCardSchema>;
export type Card = typeof cards.$inferSelect;

export type InsertVerificationResult = z.infer<typeof insertVerificationResultSchema>;
export type VerificationResult = typeof verificationResults.$inferSelect;

export type InsertCheckerConfig = z.infer<typeof insertCheckerConfigSchema>;
export type CheckerConfig = typeof checkerConfigs.$inferSelect;

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
