import { 
  type User, 
  type InsertUser,
  type VerificationSession,
  type InsertVerificationSession,
  type Card,
  type InsertCard,
  type VerificationResult,
  type InsertVerificationResult,
  type CheckerConfig,
  type InsertCheckerConfig,
  type AuditLog,
  type InsertAuditLog,
  users,
  verificationSessions,
  cards,
  verificationResults,
  checkerConfigs,
  auditLogs
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";
import { createHmac } from "crypto";
import * as argon2 from "argon2";
import session from "express-session";
import createMemoryStore from "memorystore";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean>;
  
  // Verification sessions
  createVerificationSession(session: InsertVerificationSession & { userId: string }): Promise<VerificationSession>;
  getVerificationSession(id: string): Promise<VerificationSession | undefined>;
  getUserVerificationSessions(userId: string): Promise<VerificationSession[]>;
  updateVerificationSession(id: string, updates: Partial<VerificationSession>): Promise<VerificationSession | undefined>;
  
  // Cards  
  createCard(card: { sessionId: string; cardNumber: string; expiryMonth?: string; expiryYear?: string }): Promise<Card>;
  getCard(id: string): Promise<Card | undefined>;
  getSessionCards(sessionId: string): Promise<Card[]>;
  updateCardStatus(id: string, status: string): Promise<Card | undefined>;
  
  // Verification results
  createVerificationResult(result: InsertVerificationResult): Promise<VerificationResult>;
  getVerificationResult(id: string): Promise<VerificationResult | undefined>;
  getSessionResults(sessionId: string): Promise<VerificationResult[]>;
  getCardResults(cardId: string): Promise<VerificationResult[]>;
  
  // Checker configurations
  getCheckerConfig(checkerType: string): Promise<CheckerConfig | undefined>;
  upsertCheckerConfig(config: InsertCheckerConfig): Promise<CheckerConfig>;
  getAllCheckerConfigs(): Promise<CheckerConfig[]>;
  
  // Statistics
  getUserStats(userId: string): Promise<{
    totalSessions: number;
    totalCards: number;
    totalValid: number;
    totalInvalid: number;
    totalErrors: number;
    successRate: number;
  }>;
  
  // Audit logging
  createAuditLog(log: InsertAuditLog & { userId?: string }): Promise<AuditLog>;
  
  // Session store for authentication
  sessionStore: any;
}

const MemoryStore = createMemoryStore(session);

export class PostgresStorage implements IStorage {
  sessionStore: any;
  
  constructor() {
    // Initialize session store with memory store for now
    // TODO: Switch to PostgreSQL session store once database is connected
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
  }
  // User management
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash password with Argon2id for security
    const hashedPassword = await argon2.hash(insertUser.password, {
      type: argon2.argon2id,
      memoryCost: 2 ** 16, // 64 MB
      timeCost: 3,
      parallelism: 1,
    });

    const result = await db.insert(users).values({
      ...insertUser,
      password: hashedPassword,
    }).returning();
    return result[0];
  }

  async verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean> {
    try {
      return await argon2.verify(hashedPassword, plainPassword);
    } catch (error) {
      return false;
    }
  }

  // Verification sessions
  async createVerificationSession(session: InsertVerificationSession & { userId: string }): Promise<VerificationSession> {
    const result = await db.insert(verificationSessions).values({
      ...session,
      status: 'pending'
    }).returning();
    return result[0];
  }

  async getVerificationSession(id: string): Promise<VerificationSession | undefined> {
    const result = await db.select().from(verificationSessions).where(eq(verificationSessions.id, id)).limit(1);
    return result[0];
  }

  async getUserVerificationSessions(userId: string): Promise<VerificationSession[]> {
    return await db.select()
      .from(verificationSessions)
      .where(eq(verificationSessions.userId, userId))
      .orderBy(desc(verificationSessions.createdAt));
  }

  async updateVerificationSession(id: string, updates: Partial<VerificationSession>): Promise<VerificationSession | undefined> {
    const result = await db.update(verificationSessions)
      .set(updates)
      .where(eq(verificationSessions.id, id))
      .returning();
    return result[0];
  }

  // Cards
  async createCard(card: { sessionId: string; cardNumber: string; expiryMonth?: string; expiryYear?: string }): Promise<Card> {
    // Get HMAC secret from environment
    const hmacSecret = process.env.CARD_HASH_SECRET || 'default-secret-change-in-production';
    
    // Normalize card number (remove spaces, dashes, etc.)
    const normalizedCardNumber = card.cardNumber.replace(/\D/g, '');
    
    // Generate secure HMAC-SHA256 hash of card number
    const cardNumberHash = createHmac('sha256', hmacSecret)
      .update(normalizedCardNumber)
      .digest('hex');
    
    // Create dynamic masked version based on card length
    let cardNumberMasked: string;
    if (normalizedCardNumber.length >= 8) {
      if (normalizedCardNumber.length === 16) {
        // Standard 16-digit: first 4, last 4, 8 asterisks
        cardNumberMasked = normalizedCardNumber.replace(/^(\d{4})\d{8}(\d{4})$/, '$1********$2');
      } else {
        // Other lengths: first 6, last 4, variable asterisks in middle
        const firstSix = normalizedCardNumber.slice(0, 6);
        const lastFour = normalizedCardNumber.slice(-4);
        const middleLength = normalizedCardNumber.length - 10;
        const asterisks = '*'.repeat(Math.max(middleLength, 1));
        cardNumberMasked = `${firstSix}${asterisks}${lastFour}`;
      }
    } else {
      // Short cards: mask all but first and last digit
      cardNumberMasked = normalizedCardNumber.replace(/^(\d).*(\d)$/, '$1***$2');
    }
    
    // Create the card record with hashed/masked data (no CVV stored per PCI DSS)
    const cardData = {
      sessionId: card.sessionId,
      cardNumberHash,
      cardNumberMasked,
      expiryMonth: card.expiryMonth || undefined,
      expiryYear: card.expiryYear || undefined,
    };
    
    const result = await db.insert(cards).values(cardData).returning();
    return result[0];
  }

  async getCard(id: string): Promise<Card | undefined> {
    const result = await db.select().from(cards).where(eq(cards.id, id)).limit(1);
    return result[0];
  }

  async getSessionCards(sessionId: string): Promise<Card[]> {
    return await db.select().from(cards).where(eq(cards.sessionId, sessionId));
  }

  async updateCardStatus(id: string, status: string): Promise<Card | undefined> {
    const result = await db.update(cards)
      .set({ status })
      .where(eq(cards.id, id))
      .returning();
    return result[0];
  }

  // ========================================
  // 📊 AQUÍ SE GUARDAN LOS RESULTADOS DE VERIFICACIÓN
  // ========================================
  // 🚨 ESTA FUNCIÓN SE LLAMA DESDE verifyCardWithChecker()
  // Verification results
  async createVerificationResult(result: InsertVerificationResult): Promise<VerificationResult> {
    // 📍 AQUÍ SE GUARDA EN LA BASE DE DATOS:
    // - El status (LIVE/DEAD/ERROR/TIMEOUT)
    // - La respuesta completa del checker
    // - Códigos de respuesta
    // - Tiempo de procesamiento
    // - Información del gateway
    
    const dbResult = await db.insert(verificationResults).values(result).returning();
    return dbResult[0];
  }

  async getVerificationResult(id: string): Promise<VerificationResult | undefined> {
    const result = await db.select().from(verificationResults).where(eq(verificationResults.id, id)).limit(1);
    return result[0];
  }

  async getSessionResults(sessionId: string): Promise<VerificationResult[]> {
    return await db.select()
      .from(verificationResults)
      .where(eq(verificationResults.sessionId, sessionId))
      .orderBy(desc(verificationResults.createdAt));
  }

  async getCardResults(cardId: string): Promise<VerificationResult[]> {
    return await db.select()
      .from(verificationResults)
      .where(eq(verificationResults.cardId, cardId))
      .orderBy(desc(verificationResults.createdAt));
  }

  // Checker configurations
  async getCheckerConfig(checkerType: string): Promise<CheckerConfig | undefined> {
    const result = await db.select().from(checkerConfigs).where(eq(checkerConfigs.checkerType, checkerType)).limit(1);
    return result[0];
  }

  async upsertCheckerConfig(config: InsertCheckerConfig): Promise<CheckerConfig> {
    const existing = await this.getCheckerConfig(config.checkerType);
    
    if (existing) {
      const result = await db.update(checkerConfigs)
        .set({ ...config, lastUpdated: new Date() })
        .where(eq(checkerConfigs.checkerType, config.checkerType))
        .returning();
      return result[0];
    } else {
      const result = await db.insert(checkerConfigs).values(config).returning();
      return result[0];
    }
  }

  async getAllCheckerConfigs(): Promise<CheckerConfig[]> {
    return await db.select().from(checkerConfigs).orderBy(checkerConfigs.checkerType);
  }

  // Statistics
  async getUserStats(userId: string): Promise<{
    totalSessions: number;
    totalCards: number;
    totalValid: number;
    totalInvalid: number;
    totalErrors: number;
    successRate: number;
  }> {
    // Get session stats
    const sessionStats = await db.select({
      count: sql<number>`count(*)::int`,
      totalCards: sql<number>`sum(total_cards)::int`,
      validCards: sql<number>`sum(valid_cards)::int`,
      invalidCards: sql<number>`sum(invalid_cards)::int`,
      errorCards: sql<number>`sum(error_cards)::int`
    })
    .from(verificationSessions)
    .where(eq(verificationSessions.userId, userId));

    const stats = sessionStats[0] || {
      count: 0,
      totalCards: 0,
      validCards: 0,
      invalidCards: 0,
      errorCards: 0
    };

    const successRate = stats.totalCards > 0 ? (stats.validCards / stats.totalCards) * 100 : 0;

    return {
      totalSessions: stats.count,
      totalCards: stats.totalCards || 0,
      totalValid: stats.validCards || 0,
      totalInvalid: stats.invalidCards || 0,
      totalErrors: stats.errorCards || 0,
      successRate: Math.round(successRate * 100) / 100
    };
  }

  // Audit logging
  async createAuditLog(log: InsertAuditLog & { userId?: string }): Promise<AuditLog> {
    const result = await db.insert(auditLogs).values(log).returning();
    return result[0];
  }
}

export const storage = new PostgresStorage();
