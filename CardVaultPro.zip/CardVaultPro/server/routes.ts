import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertVerificationSessionSchema, 
  insertCardSchema, 
  insertCheckerConfigSchema,
  VerificationSession
} from "@shared/schema";
import { z } from "zod";

// Restricted update schema for session updates (security: prevent tampering with protected fields)
const updateVerificationSessionSchema = z.object({
  name: z.string().optional(),
  // Removed status - use control endpoints for state changes
  settings: z.any().optional()
});

// Bulk cards schema for validation
const bulkCardsSchema = z.object({
  cards: z.array(z.object({
    cardNumber: z.string().min(8, "Card number must be at least 8 digits").regex(/^\d+$/, "Card number must contain only digits"),
    expiryMonth: z.string().length(2).regex(/^\d{2}$/, "Expiry month must be 2 digits").optional(),
    expiryYear: z.string().length(4).regex(/^\d{4}$/, "Expiry year must be 4 digits").optional()
  })).max(1000, "Maximum 1000 cards per batch")
});

// User-scoped checker config schema
const userCheckerConfigSchema = insertCheckerConfigSchema.extend({
  userId: z.string()
});

// Authentication middleware
function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}

// Audit logging helper
async function logAction(req: Request, action: string, resourceType: string, resourceId?: string, details?: any) {
  if (req.user) {
    await storage.createAuditLog({
      userId: req.user.id,
      action,
      resourceType,
      resourceId,
      details,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes: /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // User statistics - protected route
  app.get("/api/stats", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getUserStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ error: "Failed to fetch statistics" });
    }
  });

  // Verification sessions endpoints
  app.post("/api/sessions", requireAuth, async (req, res) => {
    try {
      const validation = insertVerificationSessionSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validation.error.issues 
        });
      }

      const session = await storage.createVerificationSession({
        ...validation.data,
        userId: req.user!.id
      });

      await logAction(req, 'create', 'verification_session', session.id, { checkerType: session.checkerType });
      res.status(201).json(session);
    } catch (error) {
      console.error("Error creating verification session:", error);
      res.status(500).json({ error: "Failed to create verification session" });
    }
  });

  app.get("/api/sessions", requireAuth, async (req, res) => {
    try {
      const sessions = await storage.getUserVerificationSessions(req.user!.id);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching sessions:", error);
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.get("/api/sessions/:id", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      res.json(session);
    } catch (error) {
      console.error("Error fetching session:", error);
      res.status(500).json({ error: "Failed to fetch session" });
    }
  });

  app.patch("/api/sessions/:id", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      // Security: validate with restricted schema to prevent tampering with protected fields
      const validation = updateVerificationSessionSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(422).json({ 
          error: "Validation failed", 
          details: validation.error.issues 
        });
      }

      const updatedSession = await storage.updateVerificationSession(req.params.id, validation.data);
      
      await logAction(req, 'update', 'verification_session', req.params.id, validation.data);
      res.json(updatedSession);
    } catch (error) {
      console.error("Error updating session:", error);
      res.status(500).json({ error: "Failed to update session" });
    }
  });

  // Cards endpoints
  app.post("/api/sessions/:sessionId/cards", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      const validation = insertCardSchema.extend({
        cardNumber: z.string().min(8, "Card number must be at least 8 digits")
      }).safeParse({
        ...req.body,
        sessionId: req.params.sessionId
      });

      if (!validation.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validation.error.issues 
        });
      }

      const card = await storage.createCard({
        sessionId: req.params.sessionId,
        cardNumber: validation.data.cardNumber,
        expiryMonth: validation.data.expiryMonth || undefined,
        expiryYear: validation.data.expiryYear || undefined
      });

      await logAction(req, 'create', 'card', card.id, { sessionId: req.params.sessionId });
      res.status(201).json(card);
    } catch (error) {
      console.error("Error creating card:", error);
      res.status(500).json({ error: "Failed to create card" });
    }
  });

  app.post("/api/sessions/:sessionId/cards/bulk", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      // Security: validate with structured schema and enforce limits
      const validation = bulkCardsSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validation.error.issues 
        });
      }

      const { cards } = validation.data;
      const createdCards = [];
      const errors: any[] = [];
      let validCount = 0;

      for (let i = 0; i < cards.length; i++) {
        const cardData = cards[i];
        try {
          const card = await storage.createCard({
            sessionId: req.params.sessionId,
            cardNumber: cardData.cardNumber,
            expiryMonth: cardData.expiryMonth,
            expiryYear: cardData.expiryYear
          });
          createdCards.push(card);
          validCount++;
        } catch (error) {
          console.error(`Error creating card ${i}:`, error);
          errors.push({
            index: i,
            cardNumber: cardData.cardNumber.slice(0, 4) + '****',
            error: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }

      // Update session with incremental card count (cumulative)
      const currentSession = await storage.getVerificationSession(req.params.sessionId);
      const newTotalCards = (currentSession?.totalCards || 0) + validCount;
      await storage.updateVerificationSession(req.params.sessionId, {
        totalCards: newTotalCards
      });

      await logAction(req, 'bulk_create', 'cards', req.params.sessionId, { 
        total: cards.length, 
        valid: validCount, 
        invalid: errors.length 
      });

      res.status(201).json({
        message: `Processed ${cards.length} cards`,
        created: validCount,
        failed: errors.length,
        errors: errors.length > 0 ? errors : undefined,
        cards: createdCards
      });
    } catch (error) {
      console.error("Error bulk creating cards:", error);
      res.status(500).json({ error: "Failed to bulk create cards" });
    }
  });

  app.get("/api/sessions/:sessionId/cards", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      const cards = await storage.getSessionCards(req.params.sessionId);
      res.json(cards);
    } catch (error) {
      console.error("Error fetching cards:", error);
      res.status(500).json({ error: "Failed to fetch cards" });
    }
  });

  // Public results endpoint (for unauthenticated access to general results)
  app.get("/api/results", async (req, res) => {
    try {
      // Return sample/demo results for unauthenticated users
      const demoResults: any[] = [];
      res.json(demoResults);
    } catch (error) {
      console.error("Error fetching public results:", error);
      res.status(500).json({ error: "Failed to fetch results" });
    }
  });

  // Verification results endpoints
  // ========================================
  // 📊 ENDPOINT PARA OBTENER RESULTADOS DE VERIFICACIÓN
  // ========================================
  // 🚨 AQUÍ ES DONDE EL FRONTEND RECIBE LOS RESULTADOS (LIVE/DEAD)
  app.get("/api/sessions/:sessionId/results", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      // 📍 AQUÍ SE OBTIENEN LOS RESULTADOS DE LA BASE DE DATOS
      // Estos resultados vienen de la función verifyCardWithChecker()
      const results = await storage.getSessionResults(req.params.sessionId);
      
      // 🎯 ESTOS RESULTADOS CONTIENEN:
      // - status: 'LIVE' | 'DEAD' | 'ERROR' | 'TIMEOUT'
      // - response: respuesta completa del checker
      // - responseCode: código de respuesta HTTP
      // - processingTimeMs: tiempo que tardó
      // - gatewayInfo: información adicional del gateway
      
      res.json(results);
    } catch (error) {
      console.error("Error fetching results:", error);
      res.status(500).json({ error: "Failed to fetch results" });
    }
  });

  // ========================================
  // 🔍 ENDPOINT PARA RESULTADOS DE TARJETA ESPECÍFICA
  // ========================================
  // 🚨 AQUÍ EL FRONTEND PUEDE VER EL RESULTADO DETALLADO DE UNA TARJETA
  app.get("/api/cards/:cardId/results", requireAuth, async (req, res) => {
    try {
      const card = await storage.getCard(req.params.cardId);
      if (!card) {
        return res.status(404).json({ error: "Card not found" });
      }

      // Check if user owns this card through session
      const session = await storage.getVerificationSession(card.sessionId);
      if (!session || session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      // 📍 AQUÍ SE OBTIENE EL RESULTADO ESPECÍFICO DE UNA TARJETA
      // Este resultado viene directamente de verifyCardWithChecker()
      const results = await storage.getCardResults(req.params.cardId);
      
      // 🎯 EL RESULTADO CONTIENE LA RESPUESTA COMPLETA DEL CHECKER:
      // - Todo lo que respondió el API del checker
      // - Si es LIVE, DEAD, ERROR o TIMEOUT
      // - Códigos de respuesta específicos
      
      res.json(results);
    } catch (error) {
      console.error("Error fetching card results:", error);
      res.status(500).json({ error: "Failed to fetch card results" });
    }
  });

  // Checker configuration endpoints (read-only for security)
  app.get("/api/checkers", requireAuth, async (req, res) => {
    try {
      // 🔧 CONFIGURACIÓN DE CHECKERS - AQUÍ MODIFICAR URLs y HEADERS
      const defaultCheckers = [
        { 
          checkerType: 'luna', 
          isEnabled: true, 
          maxConcurrent: 10, 
          rateLimit: 100, 
          timeout: 5000, 
          settings: {
            // 📍 CAMBIAR AQUÍ: URL del checker Luna
            url: 'https://api.luna-checker.com/verify',
            // 📍 CAMBIAR AQUÍ: Headers para Luna
            headers: {
              'Authorization': 'Bearer TU_TOKEN_LUNA',
              'Content-Type': 'application/json',
              'User-Agent': 'Tu-App/1.0'
            }
          } 
        },
        { 
          checkerType: 'orio', 
          isEnabled: true, 
          maxConcurrent: 8, 
          rateLimit: 80, 
          timeout: 6000, 
          settings: {
            // 📍 CAMBIAR AQUÍ: URL del checker Orio
            url: 'https://api.orio-gateway.com/check',
            // 📍 CAMBIAR AQUÍ: Headers para Orio
            headers: {
              'X-API-Key': 'TU_CLAVE_ORIO',
              'Content-Type': 'application/x-www-form-urlencoded'
            }
          } 
        },
        { 
          checkerType: 'ady', 
          isEnabled: true, 
          maxConcurrent: 15, 
          rateLimit: 120, 
          timeout: 4000, 
          settings: {
            // 📍 CAMBIAR AQUÍ: URL del checker Ady
            url: 'https://ady-validator.net/api/validate',
            headers: {
              'Authorization': 'ApiKey TU_TOKEN_ADY',
              'Accept': 'application/json'
            }
          } 
        },
        { 
          checkerType: 'manzana', 
          isEnabled: true, 
          maxConcurrent: 5, 
          rateLimit: 60, 
          timeout: 8000, 
          settings: {
            // 📍 CAMBIAR AQUÍ: URL del checker Manzana
            url: 'https://manzana-bin.co/verify',
            headers: {
              'X-Auth-Token': 'TU_TOKEN_MANZANA',
              'Content-Type': 'application/json'
            }
          } 
        },
        { 
          checkerType: 'stritt', 
          isEnabled: true, 
          maxConcurrent: 12, 
          rateLimit: 100, 
          timeout: 5000, 
          settings: {
            // 📍 CAMBIAR AQUÍ: URL del checker Stritt
            url: 'https://stritt-security.com/api/check',
            headers: {
              'Authorization': 'Bearer TU_JWT_STRITT',
              'X-Client-ID': 'TU_CLIENT_ID'
            }
          } 
        }
      ];
      res.json(defaultCheckers);
    } catch (error) {
      console.error("Error fetching checker configs:", error);
      res.status(500).json({ error: "Failed to fetch checker configurations" });
    }
  });

  // Checker status endpoint for real-time status display in sidebar
  app.get("/api/checkers/status", requireAuth, async (req, res) => {
    try {
      // Get active sessions per checker type for real status
      const userSessions = await storage.getUserVerificationSessions(req.user!.id);
      
      const checkerStatuses = [
        {
          name: "LUNA",
          icon: null, // Will be handled in frontend
          status: getCheckerStatus(userSessions, 'luna'),
          count: getCheckerCount(userSessions, 'luna')
        },
        {
          name: "ORIO", 
          icon: null,
          status: getCheckerStatus(userSessions, 'orio'),
          count: getCheckerCount(userSessions, 'orio')
        },
        {
          name: "ADY",
          icon: null,
          status: getCheckerStatus(userSessions, 'ady'), 
          count: getCheckerCount(userSessions, 'ady')
        },
        {
          name: "MANZANA",
          icon: null,
          status: getCheckerStatus(userSessions, 'manzana'),
          count: getCheckerCount(userSessions, 'manzana')
        },
        {
          name: "STRITT",
          icon: null,
          status: getCheckerStatus(userSessions, 'stritt'),
          count: getCheckerCount(userSessions, 'stritt')
        }
      ];
      
      res.json(checkerStatuses);
    } catch (error) {
      console.error("Error fetching checker status:", error);
      res.status(500).json({ error: "Failed to fetch checker status" });
    }
  });

  function getCheckerStatus(sessions: VerificationSession[], checkerType: string) {
    const checkerSessions = sessions.filter(s => s.checkerType === checkerType);
    if (checkerSessions.some(s => s.status === 'running')) return 'running';
    if (checkerSessions.some(s => s.status === 'paused')) return 'paused';
    if (checkerSessions.some(s => s.status === 'completed')) return 'completed';
    return 'idle';
  }

  function getCheckerCount(sessions: VerificationSession[], checkerType: string) {
    return sessions
      .filter(s => s.checkerType === checkerType && s.status !== 'completed')
      .reduce((sum, s) => sum + (s.totalCards || 0), 0);
  }

  app.get("/api/checkers/:type", requireAuth, async (req, res) => {
    try {
      // Return default config for the requested checker type (read-only for security)
      const defaultConfigs = {
        luna: { checkerType: 'luna', isEnabled: true, maxConcurrent: 10, rateLimit: 100, timeout: 5000, settings: {} },
        orio: { checkerType: 'orio', isEnabled: true, maxConcurrent: 8, rateLimit: 80, timeout: 6000, settings: {} },
        ady: { checkerType: 'ady', isEnabled: true, maxConcurrent: 15, rateLimit: 120, timeout: 4000, settings: {} },
        manzana: { checkerType: 'manzana', isEnabled: true, maxConcurrent: 5, rateLimit: 60, timeout: 8000, settings: {} },
        stritt: { checkerType: 'stritt', isEnabled: true, maxConcurrent: 12, rateLimit: 100, timeout: 5000, settings: {} }
      };

      const config = defaultConfigs[req.params.type as keyof typeof defaultConfigs];
      if (!config) {
        return res.status(404).json({ error: "Checker type not found" });
      }

      res.json(config);
    } catch (error) {
      console.error("Error fetching checker config:", error);
      res.status(500).json({ error: "Failed to fetch checker configuration" });
    }
  });

  // ========================================
  // 🚨 AQUÍ EMPIEZAS A MODIFICAR PARA CHECKERS REALES 🚨
  // ========================================
  
  // Verification control endpoints (start/pause/stop)
  app.post("/api/sessions/:sessionId/start", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      const updatedSession = await storage.updateVerificationSession(req.params.sessionId, {
        status: 'running',
        startedAt: new Date()
      });

      // 🔥 AQUÍ SE INICIA EL PROCESAMIENTO REAL DE TARJETAS
      // 📍 LLAMAR A LA FUNCIÓN REAL:
      // DESCOMENTAR ESTA LÍNEA CUANDO TENGAS LOS CHECKERS LISTOS:
      // import { processCardsWithChecker } from './checkers';
      // processCardsWithChecker(session.id, session.checkerType);
      
      await logAction(req, 'start', 'verification_session', req.params.sessionId);
      res.json(updatedSession);
    } catch (error) {
      console.error("Error starting verification:", error);
      res.status(500).json({ error: "Failed to start verification" });
    }
  });

  app.post("/api/sessions/:sessionId/pause", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      const updatedSession = await storage.updateVerificationSession(req.params.sessionId, {
        status: 'paused'
      });

      await logAction(req, 'pause', 'verification_session', req.params.sessionId);
      res.json(updatedSession);
    } catch (error) {
      console.error("Error pausing verification:", error);
      res.status(500).json({ error: "Failed to pause verification" });
    }
  });

  app.post("/api/sessions/:sessionId/stop", requireAuth, async (req, res) => {
    try {
      const session = await storage.getVerificationSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if user owns this session
      if (session.userId !== req.user!.id) {
        return res.status(403).json({ error: "Access denied" });
      }

      const updatedSession = await storage.updateVerificationSession(req.params.sessionId, {
        status: 'completed',
        completedAt: new Date()
      });

      await logAction(req, 'stop', 'verification_session', req.params.sessionId);
      res.json(updatedSession);
    } catch (error) {
      console.error("Error stopping verification:", error);
      res.status(500).json({ error: "Failed to stop verification" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
