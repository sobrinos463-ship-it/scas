# Credit Card Verification Platform Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from professional security and fintech platforms like Stripe Dashboard, Auth0 Management Console, and enterprise security tools. The design emphasizes trust, security, and operational efficiency through clean interfaces and clear data presentation.

## Core Design Elements

### A. Color Palette
**Dark Mode Primary** (default):
- Background: 220 15% 8% (deep navy-black)
- Surface: 220 15% 12% (elevated dark surfaces)
- Primary: 210 85% 45% (professional blue)
- Success: 142 72% 35% (secure green for "VIVA")
- Danger: 0 75% 50% (alert red for "MUERTA") 
- Text Primary: 0 0% 95% (high contrast white)
- Text Secondary: 0 0% 70% (muted gray)

**Light Mode** (optional toggle):
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Same accent colors with adjusted lightness

### B. Typography
- **Primary**: Inter (Google Fonts) - clean, professional
- **Monospace**: JetBrains Mono for card numbers and technical data
- **Hierarchy**: text-3xl/2xl for headings, text-base for body, text-sm for metadata

### C. Layout System
**Tailwind Spacing**: Consistent use of 2, 4, 6, 8, 12, 16 units
- Micro spacing: p-2, gap-2
- Standard spacing: p-4, m-4, gap-4  
- Section spacing: p-8, my-8
- Large spacing: p-12, my-16

### D. Component Library

**Navigation**:
- Collapsible sidebar with checker icons and status indicators
- Top navigation bar with user profile, notifications, and quick actions
- Breadcrumb navigation for deep functionality

**Checker Cards**:
- Individual cards for each checker (Luna, Orio, Ady, Manzana, Stritt)
- Status indicators (Active/Idle) with colored dots
- Quick stats display (Success rate, Last run, Queue count)
- Distinctive icons for each checker type

**Data Display**:
- Tables with fixed headers for card verification results
- Color-coded status badges (VIVA=green, MUERTA=red, PENDING=yellow)
- Expandable rows for detailed response data
- Real-time progress bars during batch processing

**Forms**:
- Dark-themed input fields with subtle borders
- File upload areas with drag-and-drop styling
- Multi-select dropdowns for checker configuration
- Tabbed interfaces for different input methods (manual, CSV, API)

**Modals/Overlays**:
- Configuration panels for each checker
- Results detail modals with JSON response viewers
- Confirmation dialogs for sensitive operations

### E. Dashboard Layout

**Main Dashboard**:
- Grid layout with checker status cards (3x2 on desktop, stacked mobile)
- Live statistics panel showing total checks, success rates, recent activity
- Quick action buttons for batch uploads and emergency stops

**Individual Checker Pages**:
- Split-screen layout: configuration panel (left) + results table (right)
- Real-time logs section at bottom
- Progress tracking with estimated completion times

## Security & Trust Design Elements

**Visual Security Cues**:
- Subtle lock icons and security badges
- Encrypted data transmission indicators
- Session timeout warnings
- SSL certificate displays

**Professional Aesthetics**:
- Minimal use of gradients (only for status indicators)
- High contrast ratios for accessibility
- Consistent spacing and alignment
- Professional color scheme avoiding flashy elements

## Responsive Behavior
- Mobile: Single-column layout with collapsible sections
- Tablet: 2-column adaptive layout
- Desktop: Full multi-panel interface with fixed sidebar

## Special Considerations
- No hero images (security-focused interface)
- Monospace fonts for all card data display
- Real-time updates without page refresh
- Clear error states and loading indicators
- Export functionality prominently displayed
- Dark mode as default to reduce eye strain during extended use

This design emphasizes operational efficiency, data clarity, and professional security aesthetics appropriate for a sensitive financial verification platform.