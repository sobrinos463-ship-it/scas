# Credit Card Verification Platform

## Overview

This is a professional credit card verification platform called "CreditCheck Pro" that provides advanced card validation services through multiple verification checkers (Luna, Orio, Ady, Manzana, and Stritt). The platform is designed as a fintech security tool with a dark-mode aesthetic inspired by professional platforms like Stripe Dashboard and Auth0 Management Console.

The system enables bulk processing of credit card data through various verification algorithms, with real-time status tracking, comprehensive reporting, and secure data handling. It features a sophisticated dashboard for monitoring verification sessions, managing checker configurations, and analyzing results.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React + TypeScript**: Modern React application with TypeScript for type safety
- **Vite**: Fast development server and build tool with hot module replacement
- **Tailwind CSS**: Utility-first CSS framework with custom dark mode theme
- **Shadcn/UI + Radix UI**: Component library built on Radix primitives for accessibility
- **Wouter**: Lightweight client-side routing library
- **TanStack Query**: Server state management for API calls and caching

### Backend Architecture  
- **Express.js**: RESTful API server with TypeScript
- **Passport.js**: Authentication middleware with local strategy and session management
- **Drizzle ORM**: Type-safe database ORM with PostgreSQL dialect
- **Session-based Authentication**: Server-side session management with memory store
- **Argon2**: Password hashing for secure user credentials

### Database Schema
- **Users**: Authentication and user management
- **Verification Sessions**: Bulk card processing workflows with status tracking
- **Cards**: Individual card storage with HMAC-SHA256 hashing and masking for security
- **Verification Results**: Individual card verification outcomes with performance metrics
- **Checker Configs**: User-specific checker configurations and settings
- **Audit Logs**: Security and compliance logging for all system actions

### Security Features
- **Data Protection**: Card numbers are hashed using HMAC-SHA256 and stored with masking (e.g., "4532************1234")
- **Authentication**: Session-based auth with secure cookie settings
- **Authorization**: User-scoped access to verification sessions and results
- **Audit Trail**: Comprehensive logging of all user actions and system events
- **Input Validation**: Zod schemas for request validation and data sanitization

### Verification System
- **Multiple Checkers**: Five different verification algorithms (Luna, Orio, Ady, Manzana, Stritt) each with unique capabilities
- **Bulk Processing**: Handle up to 1000 cards per batch with progress tracking
- **Real-time Updates**: WebSocket-like updates for verification progress and results
- **Status Management**: Comprehensive status tracking (pending, running, completed, failed, paused)
- **Performance Metrics**: Processing time tracking and success rate analytics

### UI/UX Design
- **Dark Mode First**: Professional security-focused aesthetic with navy-black backgrounds
- **Responsive Design**: Mobile-first approach with collapsible sidebar navigation
- **Component Architecture**: Modular component system with consistent spacing and typography
- **Data Visualization**: Tables, progress bars, and statistical dashboards for verification results
- **Accessibility**: Built on Radix UI primitives ensuring ARIA compliance

## External Dependencies

### Database
- **Neon PostgreSQL**: Serverless PostgreSQL database with connection pooling
- **Drizzle Kit**: Database migration and schema management tools

### Authentication & Security
- **Express Session**: Session management with configurable stores
- **Argon2**: Modern password hashing algorithm
- **Passport.js**: Authentication middleware with multiple strategy support

### Frontend Libraries
- **React Query**: Server state management and caching
- **Radix UI**: Headless UI components for accessibility
- **Tailwind CSS**: Utility-first styling framework
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **TypeScript**: Type safety across frontend and backend
- **Vite**: Fast development and build tooling
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind integration

### Payment Integration Ready
- **Stripe Dependencies**: Pre-configured for potential payment gateway integration
- **Webhook Support**: Infrastructure ready for external service notifications