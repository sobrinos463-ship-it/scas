module.exports = {
  apps: [{
    name: 'cardvaultpro',
    script: './dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
      // DATABASE_URL and SESSION_SECRET should be set via system environment
      // or PM2 environment injection for security
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
      // DATABASE_URL and SESSION_SECRET should be set via system environment  
      // or PM2 environment injection for security
    }
  }]
};