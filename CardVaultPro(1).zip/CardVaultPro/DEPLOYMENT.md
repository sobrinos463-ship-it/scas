# Guía de Despliegue - CardVaultpro

## ⚠️ CRÍTICO - Configuración de Seguridad

**NUNCA hardcodees credenciales en archivos de código. Las credenciales deben configurarse como variables de entorno del sistema.**

### 🚨 ROTACIÓN DE SECRETOS REQUERIDA

Si este proyecto previamente tenía credenciales hardcodeadas en el código, **DEBES rotar inmediatamente**:
1. **Cambia la contraseña del usuario de base de datos**
2. **Genera un nuevo SESSION_SECRET**
3. **Si usas servicios externos, regenera las API keys**

```bash
# Ejemplo: cambiar contraseña en PostgreSQL
sudo -u postgres psql
ALTER USER tu_usuario PASSWORD 'nueva_password_muy_segura';
\q

# Generar nuevo SESSION_SECRET (64 caracteres aleatorios)
openssl rand -hex 32
```

## Requisitos Previos

1. **Node.js** v20 o superior
2. **PostgreSQL** corriendo y accesible  
3. **PM2** para manejo de procesos
4. **Acceso de red** al servidor de base de datos

## Pasos de Despliegue

### 1. Verificar PostgreSQL

```bash
# Verificar si PostgreSQL está corriendo
sudo systemctl status postgresql

# Si no está instalado/corriendo:
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 2. Configurar Base de Datos

```bash
# Conectar como usuario postgres
sudo -u postgres psql

# Crear base de datos y usuario (usar tus credenciales reales)
CREATE DATABASE tu_database_name;
CREATE USER tu_usuario WITH PASSWORD 'tu_password_seguro';
GRANT ALL PRIVILEGES ON DATABASE tu_database_name TO tu_usuario;
\q

# Probar conectividad
psql -h localhost -p 5432 -U tu_usuario -d tu_database_name
```

### 📡 Para Bases de Datos Remotas/Gestionadas

Si usas un servicio como Neon, AWS RDS, o similar:

```bash
# DATABASE_URL debe incluir SSL
DATABASE_URL="postgresql://usuario:password@host:5432/database?sslmode=require"

# O configurar SSL globalmente
export PGSSLMODE=require

# Probar conectividad antes de continuar
psql "$DATABASE_URL"
```

### 3. Configurar Variables de Entorno de Forma Segura

**Opción A: Variables de sistema (recomendado)**
```bash
# Agregar al final de /etc/environment
sudo nano /etc/environment

# Agregar estas líneas (con tus valores reales):
DATABASE_URL="postgresql://tu_usuario:tu_password@localhost:5432/tu_database"
SESSION_SECRET="tu_session_secret_muy_largo_y_aleatorio"
```

**Opción B: Variables de entorno en sesión**
```bash
# Configurar variables en la sesión actual antes de iniciar PM2
export DATABASE_URL="postgresql://tu_usuario:tu_password@localhost:5432/tu_database"
export SESSION_SECRET="tu_session_secret_muy_largo_y_aleatorio"

# Luego iniciar PM2 (las variables se heredarán)
pm2 start ecosystem.config.js --env production --update-env
pm2 save
```

### 4. Instalar Dependencias y Construir

```bash
cd /opt/CardVaultpro
npm ci
npm run build
```

### 5. Ejecutar Migraciones

```bash
# Asegúrate de que DATABASE_URL esté configurado
echo $DATABASE_URL  # Debe mostrar tu URL de base de datos

# Ejecutar migraciones
npm run db:push
# Si falla, usar: npm run db:push --force
```

### 6. Iniciar con PM2

```bash
# Asegúrate de que las variables de entorno estén configuradas
echo $DATABASE_URL
echo $SESSION_SECRET

# Iniciar la aplicación
pm2 start ecosystem.config.js --env production --update-env

# Verificar estado
pm2 status

# Ver logs en tiempo real
pm2 logs cardvaultpro

# Configurar autostart
pm2 startup
pm2 save
```

### 🔄 Cambiar Variables de Entorno

Si necesitas cambiar las variables de entorno después del despliegue:

```bash
# Actualizar variables del sistema (/etc/environment) o exportar nuevas
export DATABASE_URL="nueva_url"
export SESSION_SECRET="nuevo_secret"

# Reiniciar PM2 con las nuevas variables
pm2 restart cardvaultpro --update-env
pm2 save
```

## Verificación del Despliegue

1. **Comprobar proceso**: `pm2 status`
2. **Verificar puerto**: `netstat -tlnp | grep 5000`
3. **Probar conectividad**: `curl http://localhost:5000`
4. **Revisar logs**: `pm2 logs cardvaultpro`

## Solución de Problemas

### Error: "DATABASE_URL must be set"
- Verificar variables de entorno: `echo $DATABASE_URL`
- Reiniciar PM2: `pm2 restart cardvaultpro`
- Verificar ecosystem.config.js

### Error: "ECONNREFUSED"
- Verificar PostgreSQL: `sudo systemctl status postgresql`
- Comprobar conectividad: `pg_isready -h localhost -p 5432`
- Verificar credenciales de base de datos

### Error de puerto en uso
- Verificar procesos: `lsof -i :5000`
- Cambiar puerto en variables de entorno: `PORT=3000`

## Comandos Útiles PM2

```bash
pm2 restart cardvaultpro    # Reiniciar aplicación
pm2 stop cardvaultpro       # Detener aplicación  
pm2 delete cardvaultpro     # Eliminar del PM2
pm2 reload cardvaultpro     # Recarga sin downtime
pm2 monit                   # Monitor en tiempo real
```

## Seguridad

- ✅ Nunca commitear credenciales en código
- ✅ Usar variables de entorno del sistema
- ✅ Rotar secretos regularmente
- ✅ Configurar firewall apropiadamente
- ✅ Mantener dependencias actualizadas