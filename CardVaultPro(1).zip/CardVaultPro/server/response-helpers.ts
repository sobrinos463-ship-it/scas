// ========================================
// 🔧 HERRAMIENTAS AVANZADAS PARA PARSING DE RESPUESTAS COMPLEJAS
// ========================================
// 🚨 USA ESTAS FUNCIONES CUANDO LAS RESPUESTAS SEAN MUY COMPLICADAS

/**
 * 🔍 EXTRAE DATOS DE HTML COMPLEJO
 * Útil cuando el checker responde con HTML y necesitas datos específicos
 */
export function extractFromHTML(html: string, selectors: {
  status?: string;
  message?: string;
  code?: string;
  [key: string]: string | undefined;
}): Record<string, string | null> {
  const results: Record<string, string | null> = {};
  
  // 🚨 EJEMPLO: Extraer por atributos ID
  if (selectors.status) {
    const statusMatch = html.match(new RegExp(`id="${selectors.status}"[^>]*>([^<]+)<`, 'i'));
    results.status = statusMatch ? statusMatch[1].trim() : null;
  }
  
  // 🚨 EJEMPLO: Extraer por clases CSS
  if (selectors.message) {
    const messageMatch = html.match(new RegExp(`class="${selectors.message}"[^>]*>([^<]+)<`, 'i'));
    results.message = messageMatch ? messageMatch[1].trim() : null;
  }
  
  // 🚨 EJEMPLO: Extraer de tablas
  const tableMatch = html.match(/<table[^>]*>([\s\S]*?)<\/table>/i);
  if (tableMatch) {
    const tableContent = tableMatch[1];
    const cellMatches = tableContent.match(/<td[^>]*>([^<]+)<\/td>/gi);
    if (cellMatches) {
      results.tableData = cellMatches.map(cell => 
        cell.replace(/<\/?td[^>]*>/gi, '').trim()
      ).join('|');
    }
  }
  
  return results;
}

/**
 * 🔍 EXTRAE DATOS DE XML
 * Para checkers que responden con XML
 */
export function extractFromXML(xml: string, tags: string[]): Record<string, string | null> {
  const results: Record<string, string | null> = {};
  
  for (const tag of tags) {
    const regex = new RegExp(`<${tag}[^>]*>([^<]+)<\/${tag}>`, 'i');
    const match = xml.match(regex);
    results[tag] = match ? match[1].trim() : null;
  }
  
  return results;
}

/**
 * 🔍 EXTRAE DATOS CON REGEX AVANZADOS
 * Para patrones complejos en respuestas de texto
 */
export function extractWithPatterns(text: string, patterns: {
  [key: string]: RegExp;
}): Record<string, string | null> {
  const results: Record<string, string | null> = {};
  
  for (const [key, pattern] of Object.entries(patterns)) {
    const match = text.match(pattern);
    results[key] = match ? match[1] : null;
  }
  
  return results;
}

/**
 * 🔍 LIMPIA Y DECODIFICA RESPUESTAS
 * Para respuestas con encoding especial o caracteres raros
 */
export function cleanResponse(response: string): string {
  return response
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\\t/g, '\t')
    .replace(/\\\\/g, '\\')
    .replace(/\\"/g, '"')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .trim();
}

/**
 * 🔍 DETECTA ENCODING Y CONVIERTE
 * Para respuestas con encoding diferente a UTF-8
 */
export function detectAndConvert(buffer: ArrayBuffer): string {
  // Intentar UTF-8 primero
  try {
    const text = new TextDecoder('utf-8').decode(buffer);
    if (!text.includes('�')) return text;
  } catch {}
  
  // Intentar Latin-1
  try {
    return new TextDecoder('latin1').decode(buffer);
  } catch {}
  
  // Intentar Windows-1252
  try {
    return new TextDecoder('windows-1252').decode(buffer);
  } catch {}
  
  // Fallback a UTF-8
  return new TextDecoder('utf-8', { fatal: false }).decode(buffer);
}

/**
 * 🔍 PARSER PARA RESPUESTAS MULTI-FORMATO
 * Cuando el checker puede responder JSON, XML, HTML o texto según el caso
 */
export function parseMultiFormat(response: string): {
  type: 'json' | 'xml' | 'html' | 'text';
  data: any;
  raw: string;
} {
  const cleaned = cleanResponse(response);
  
  // Detectar JSON
  if (cleaned.startsWith('{') || cleaned.startsWith('[')) {
    try {
      return {
        type: 'json',
        data: JSON.parse(cleaned),
        raw: cleaned
      };
    } catch {}
  }
  
  // Detectar XML
  if (cleaned.includes('<?xml') || cleaned.startsWith('<') && cleaned.includes('</')) {
    return {
      type: 'xml',
      data: cleaned,
      raw: cleaned
    };
  }
  
  // Detectar HTML
  if (cleaned.includes('<html') || cleaned.includes('<body') || cleaned.includes('<div')) {
    return {
      type: 'html',
      data: cleaned,
      raw: cleaned
    };
  }
  
  // Es texto plano
  return {
    type: 'text',
    data: cleaned,
    raw: cleaned
  };
}

/**
 * 🔍 BUSCA PATRONES DE LIVE/DEAD EN CUALQUIER FORMATO
 * Función universal para detectar LIVE/DEAD
 */
export function detectCardStatus(response: any, customPatterns?: {
  live: (RegExp | string)[];
  dead: (RegExp | string)[];
}): 'LIVE' | 'DEAD' | 'UNKNOWN' {
  let textToAnalyze = '';
  
  // Convertir respuesta a texto analizable
  if (typeof response === 'string') {
    textToAnalyze = response;
  } else if (typeof response === 'object') {
    textToAnalyze = JSON.stringify(response);
  } else {
    textToAnalyze = String(response);
  }
  
  textToAnalyze = textToAnalyze.toLowerCase();
  
  // Patrones por defecto
  const defaultLivePatterns = [
    /approved|success|charged|valid|live|accepted|authorized/,
    /status[:\s]*["\']?(1|true|approved|live|success)["\']?/,
    /result[:\s]*["\']?(1|true|approved|live|success)["\']?/,
    /code[:\s]*["\']?(00|000|200)["\']?/
  ];
  
  const defaultDeadPatterns = [
    /declined|failed|invalid|dead|rejected|denied|error/,
    /status[:\s]*["\']?(0|false|declined|dead|failed)["\']?/,
    /result[:\s]*["\']?(0|false|declined|dead|failed)["\']?/,
    /code[:\s]*["\']?(05|14|400|402|403)["\']?/
  ];
  
  // Usar patrones personalizados si se proporcionan
  const livePatterns = customPatterns?.live || defaultLivePatterns;
  const deadPatterns = customPatterns?.dead || defaultDeadPatterns;
  
  // Buscar patrones LIVE
  for (const pattern of livePatterns) {
    if (pattern instanceof RegExp) {
      if (pattern.test(textToAnalyze)) return 'LIVE';
    } else {
      if (textToAnalyze.includes(pattern.toLowerCase())) return 'LIVE';
    }
  }
  
  // Buscar patrones DEAD
  for (const pattern of deadPatterns) {
    if (pattern instanceof RegExp) {
      if (pattern.test(textToAnalyze)) return 'DEAD';
    } else {
      if (textToAnalyze.includes(pattern.toLowerCase())) return 'DEAD';
    }
  }
  
  return 'UNKNOWN';
}

// ========================================
// 🎯 EJEMPLOS DE USO
// ========================================

/*
// 🚨 EJEMPLO 1: Para HTML complejo
const htmlData = extractFromHTML(response.body, {
  status: 'card-status',
  message: 'response-message',
  code: 'result-code'
});

if (htmlData.status === 'approved') {
  return { status: 'LIVE', response: response.body };
}

// 🚨 EJEMPLO 2: Para XML
const xmlData = extractFromXML(response.body, ['status', 'code', 'message']);
if (xmlData.status === 'approved') {
  return { status: 'LIVE', response: response.body };
}

// 🚨 EJEMPLO 3: Para patrones complejos
const patterns = {
  status: /status[:\s]*["\']?([^"'\s]+)["\']?/i,
  amount: /amount[:\s]*["\']?(\d+\.?\d*)["\']?/i,
  gateway: /gateway[:\s]*["\']?([^"'\s]+)["\']?/i
};

const extracted = extractWithPatterns(response.body, patterns);
if (extracted.status === 'live') {
  return { status: 'LIVE', response: response.body };
}

// 🚨 EJEMPLO 4: Detección automática
const cardStatus = detectCardStatus(response.body);
if (cardStatus === 'LIVE') {
  return { status: 'LIVE', response: response.body };
}

// 🚨 EJEMPLO 5: Para respuestas multi-formato
const parsed = parseMultiFormat(response.body);
if (parsed.type === 'json') {
  // Manejar como JSON
} else if (parsed.type === 'html') {
  // Manejar como HTML
}
*/