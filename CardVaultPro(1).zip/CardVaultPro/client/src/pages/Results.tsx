import CardVerificationTable from "@/components/CardVerificationTable";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Download, RefreshCcw, Filter } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface ResultsStats {
  totalSessions: number;
  totalCards: number;
  totalValid: number;
  totalInvalid: number;
  totalErrors: number;
  successRate: number;
}

export default function Results() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery<ResultsStats>({
    queryKey: ['/api/stats'],
    retry: 1
  });
  
  const { data: allResults, isLoading: resultsLoading, refetch: refetchResults } = useQuery({
    queryKey: ['/api/results'],
    retry: 1
  });

  const handleRefresh = async () => {
    try {
      await Promise.all([refetchStats(), refetchResults()]);
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      toast({
        title: "Results Refreshed",
        description: "All data has been updated successfully"
      });
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh data. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleExportAll = async () => {
    try {
      const response = await fetch('/api/results/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `all_results_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast({
        title: "Export Complete",
        description: "All results have been exported successfully"
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export results. Please try again.",
        variant: "destructive"
      });
    }
  };
  return (
    <div className="p-6 space-y-8" data-testid="page-results">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Verification Results</h1>
          <p className="text-muted-foreground">
            Comprehensive analysis and detailed results from all checker operations
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={statsLoading || resultsLoading} data-testid="button-refresh">
            <RefreshCcw className={`w-4 h-4 mr-2 ${statsLoading || resultsLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportAll} data-testid="button-export-all">
            <Download className="w-4 h-4 mr-2" />
            Export All
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              {statsLoading ? (
                <Skeleton className="h-8 w-20 mx-auto mb-2" />
              ) : (
                <div className="text-2xl font-bold font-mono text-chart-2" data-testid="text-live-count">
                  {(stats?.totalValid || 0).toLocaleString()}
                </div>
              )}
              <div className="text-sm text-muted-foreground">Live Cards</div>
              {!statsLoading && stats && stats.totalValid > 0 && (
                <Badge className="bg-chart-2 text-white text-xs mt-1">Valid</Badge>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              {statsLoading ? (
                <Skeleton className="h-8 w-20 mx-auto mb-2" />
              ) : (
                <div className="text-2xl font-bold font-mono text-destructive" data-testid="text-dead-count">
                  {(stats?.totalInvalid || 0).toLocaleString()}
                </div>
              )}
              <div className="text-sm text-muted-foreground">Dead Cards</div>
              {!statsLoading && stats && stats.totalInvalid > 0 && (
                <Badge variant="destructive" className="text-xs mt-1">Invalid</Badge>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              {statsLoading ? (
                <Skeleton className="h-8 w-20 mx-auto mb-2" />
              ) : (
                <div className="text-2xl font-bold font-mono text-chart-4" data-testid="text-pending-count">
                  {Math.max(0, (stats?.totalCards || 0) - (stats?.totalValid || 0) - (stats?.totalInvalid || 0) - (stats?.totalErrors || 0)).toLocaleString()}
                </div>
              )}
              <div className="text-sm text-muted-foreground">Pending</div>
              <Badge className="bg-chart-4 text-white text-xs mt-1">Processing</Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              {statsLoading ? (
                <Skeleton className="h-8 w-20 mx-auto mb-2" />
              ) : (
                <div className="text-2xl font-bold font-mono" data-testid="text-error-count">
                  {(stats?.totalErrors || 0).toLocaleString()}
                </div>
              )}
              <div className="text-sm text-muted-foreground">Errors</div>
              <Badge variant="outline" className="text-xs mt-1">
                {stats && stats.totalCards > 0 ? ((stats.totalErrors / stats.totalCards) * 100).toFixed(1) + '%' : '0%'}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Results Table */}
      <CardVerificationTable 
        results={allResults}
        title="All Verification Results"
        showFilters={true}
        onExport={handleExportAll}
      />
    </div>
  );
}