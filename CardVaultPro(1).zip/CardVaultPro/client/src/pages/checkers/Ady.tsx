import CheckerPage from "@/components/CheckerPage";
import { Shield } from "lucide-react";

export default function Ady() {
  return (
    <CheckerPage
      name="ADY"
      description="Lightning-fast bulk validator with optimized algorithms"
      icon={<Shield className="w-6 h-6 text-white" />}
      color="bg-green-600"
      features={[
        "Bulk Processing",
        "Optimized Algorithms",
        "Lightning Speed",
        "High Volume"
      ]}
      defaultConfig={{
        speed: 'fast',
        batchSize: 500,
        skipInvalid: false,
        autoRetry: false,
        timeout: 10
      }}
    />
  );
}