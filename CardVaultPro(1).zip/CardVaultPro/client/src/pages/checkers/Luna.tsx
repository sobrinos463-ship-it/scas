import CheckerPage from "@/components/CheckerPage";
import { Moon } from "lucide-react";

export default function Luna() {
  return (
    <CheckerPage
      name="LUNA"
      description="High-precision Luhn validator with advanced pattern recognition"
      icon={<Moon className="w-6 h-6 text-white" />}
      color="bg-blue-600"
      features={[
        "Luhn Algorithm",
        "Pattern Recognition", 
        "Fast Processing",
        "High Accuracy"
      ]}
      defaultConfig={{
        speed: 'medium',
        batchSize: 100,
        skipInvalid: false,
        autoRetry: true,
        timeout: 30
      }}
    />
  );
}