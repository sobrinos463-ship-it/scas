import CheckerPage from "@/components/CheckerPage";
import { Apple } from "lucide-react";

export default function Manzana() {
  return (
    <CheckerPage
      name="MANZANA"
      description="Advanced BIN analysis with comprehensive fraud detection"
      icon={<Apple className="w-6 h-6 text-white" />}
      color="bg-red-600"
      features={[
        "BIN Analysis",
        "Fraud Detection",
        "Risk Scoring",
        "Advanced ML"
      ]}
      defaultConfig={{
        speed: 'slow',
        batchSize: 25,
        skipInvalid: false,
        autoRetry: true,
        timeout: 60
      }}
    />
  );
}