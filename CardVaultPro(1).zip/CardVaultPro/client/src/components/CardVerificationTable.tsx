import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, Download, Filter, MoreVertical, Eye } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface VerificationResult {
  id: string;
  cardId: string;
  sessionId: string;
  checkerType: string;
  status: 'LIVE' | 'DEAD' | 'ERROR' | 'TIMEOUT';
  response?: string;
  responseCode?: string;
  processingTimeMs?: number;
  gatewayInfo?: any;
  createdAt: string;
}

interface Card {
  id: string;
  sessionId: string;
  cardNumberMasked: string;
  expiryMonth?: string;
  expiryYear?: string;
  status: string;
  createdAt: string;
}

interface CardWithResults extends Card {
  results: VerificationResult[];
}

interface CardVerificationTableProps {
  sessionId?: string;
  title?: string;
  showFilters?: boolean;
  onExport?: () => void;
}

export default function CardVerificationTable({
  sessionId,
  title = "Verification Results",
  showFilters = true,
  onExport
}: CardVerificationTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [filtersVisible, setFiltersVisible] = useState(showFilters);

  // Query for verification results - either for a specific session or all recent results
  const { data: results, isLoading, error } = useQuery<VerificationResult[]>({
    queryKey: sessionId ? ['/api/sessions', sessionId, 'results'] : ['/api/results'],
    retry: 1,
    enabled: true // Always enabled, but will get auth error if not logged in
  });

  if (isLoading) {
    return (
      <Card data-testid="card-verification-results">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg font-semibold">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 border rounded">
                <div className="flex items-center gap-4">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-6 w-16 rounded" />
                </div>
                <div className="flex items-center gap-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card data-testid="card-verification-results">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            {error.message.includes('401') ? 'Please log in to view verification results' : 'Failed to load verification results'}
          </p>
        </CardContent>
      </Card>
    );
  }

  const displayResults = results || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'LIVE': return 'bg-chart-2 text-white';
      case 'DEAD': return 'bg-destructive text-destructive-foreground';
      case 'PENDING': return 'bg-chart-4 text-white';
      case 'ERROR': return 'bg-chart-5 text-white';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const filteredResults = displayResults.filter(result => {
    const matchesSearch = result.checkerType.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (result.response || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || result.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-semibold" data-testid="text-table-title">
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={onExport} data-testid="button-export">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => setFiltersVisible(prev => !prev)}
              data-testid="button-filter"
            >
              <Filter className="w-4 h-4 mr-2" />
              {filtersVisible ? 'Hide' : 'Show'} Filter
            </Button>
          </div>
        </div>
        
        {filtersVisible && (
          <div className="flex items-center gap-4 mt-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search cards, checkers, or responses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>
            <select 
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 border rounded-md bg-background text-sm"
              data-testid="select-status"
            >
              <option value="all">All Status</option>
              <option value="LIVE">Live</option>
              <option value="DEAD">Dead</option>
              <option value="PENDING">Pending</option>
              <option value="ERROR">Error</option>
            </select>
          </div>
        )}
      </CardHeader>
      
      <CardContent>
        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[180px]">Card ID</TableHead>
                <TableHead className="w-[100px]">Session</TableHead>
                <TableHead className="w-[80px]">Status</TableHead>
                <TableHead className="w-[100px]">Checker</TableHead>
                <TableHead className="w-[200px]">Response</TableHead>
                <TableHead className="w-[140px]">Timestamp</TableHead>
                <TableHead className="w-[100px]">Time (ms)</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredResults.map((result) => (
                <TableRow key={result.id} className="hover-elevate" data-testid={`row-result-${result.id}`}>
                  <TableCell className="font-mono text-sm" data-testid={`text-card-${result.id}`}>
                    {result.cardId.slice(0, 8)}...
                  </TableCell>
                  <TableCell className="font-mono text-sm" data-testid={`text-session-${result.id}`}>
                    {result.sessionId.slice(0, 8)}...
                  </TableCell>
                  <TableCell>
                    <Badge 
                      className={`${getStatusColor(result.status)} font-mono text-xs`}
                      data-testid={`badge-status-${result.id}`}
                    >
                      {result.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-semibold" data-testid={`text-checker-${result.id}`}>
                    {result.checkerType.toUpperCase()}
                  </TableCell>
                  <TableCell className="text-sm" data-testid={`text-response-${result.id}`}>
                    {result.response || 'No response'}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground" data-testid={`text-timestamp-${result.id}`}>
                    {new Date(result.createdAt).toLocaleString()}
                  </TableCell>
                  <TableCell className="font-mono text-sm" data-testid={`text-time-${result.id}`}>
                    {result.processingTimeMs || 0}ms
                  </TableCell>
                  <TableCell>
                    <Button size="icon" variant="ghost" data-testid={`button-details-${result.id}`}>
                      <Eye className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {filteredResults.length === 0 && (
            <div className="text-center py-8 text-muted-foreground" data-testid="text-no-results">
              No verification results found.
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-between text-sm text-muted-foreground mt-4">
          <span data-testid="text-results-count">
            Showing {filteredResults.length} of {displayResults.length} results
          </span>
          <div className="flex items-center gap-2">
            <span>Page 1 of 1</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}