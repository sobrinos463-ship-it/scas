import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Moon, 
  Zap, 
  Shield, 
  Apple, 
  CreditCard, 
  Upload,
  BarChart3,
  History,
  Settings,
  LogOut,
  User
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface CheckerStatus {
  name: string;
  icon: React.ReactNode;
  status: 'idle' | 'running' | 'paused' | 'completed';
  count?: number;
}

function LogoutButton() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/logout', { method: 'POST' });
      if (!response.ok) throw new Error('Logout failed');
    },
    onSuccess: () => {
      queryClient.setQueryData(['/api/user'], null);
      queryClient.clear();
      toast({
        title: "Logged out",
        description: "Successfully logged out"
      });
    }
  });

  return (
    <SidebarMenuButton 
      onClick={() => logoutMutation.mutate()}
      disabled={logoutMutation.isPending}
      data-testid="button-logout"
    >
      <LogOut className="w-4 h-4" />
      <span>{logoutMutation.isPending ? "Logging out..." : "Logout"}</span>
    </SidebarMenuButton>
  );
}

export function AppSidebar() {
  const [location] = useLocation();
  // Get real-time checker statuses from API
  const { data: checkerStatuses = [] } = useQuery<CheckerStatus[]>({
    queryKey: ['/api/checkers/status'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-chart-2 text-white';
      case 'paused': return 'bg-chart-4 text-white';
      case 'completed': return 'bg-primary text-primary-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusDot = (status: string) => {
    switch (status) {
      case 'running': return 'bg-chart-2';
      case 'paused': return 'bg-chart-4';
      case 'completed': return 'bg-primary';
      default: return 'bg-muted-foreground';
    }
  };

  const mainMenuItems = [
    {
      title: "Dashboard",
      url: "/",
      icon: LayoutDashboard,
    },
    {
      title: "Bulk Upload",
      url: "/upload",
      icon: Upload,
    },
    {
      title: "Results",
      url: "/results",
      icon: BarChart3,
    },
    {
      title: "History",
      url: "/history",
      icon: History,
    },
    {
      title: "Settings",
      url: "/settings",
      icon: Settings,
    }
  ];

  return (
    <Sidebar data-testid="sidebar-main">
      <SidebarHeader className="border-b">
        <div className="flex items-center gap-3 p-4">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <CreditCard className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <h2 className="font-bold text-lg" data-testid="text-app-title">CreditCheck Pro</h2>
            <p className="text-xs text-muted-foreground">Advanced Verification</p>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainMenuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild
                    data-active={location === item.url}
                    data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Link href={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center justify-between">
            <span>Checkers</span>
            <Badge variant="secondary" className="text-xs font-mono" data-testid="badge-active-checkers">
              {checkerStatuses.filter(c => c.status === 'running').length} running
            </Badge>
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {checkerStatuses.map((checker) => (
                <SidebarMenuItem key={checker.name}>
                  <SidebarMenuButton 
                    asChild 
                    className="justify-between"
                    data-testid={`nav-checker-${checker.name.toLowerCase()}`}
                  >
                    <Link href={`/checker/${checker.name.toLowerCase()}`}>
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          {checker.icon}
                          <div 
                            className={`absolute -top-1 -right-1 w-2 h-2 rounded-full ${getStatusDot(checker.status)}`}
                            data-testid={`status-dot-${checker.name.toLowerCase()}`}
                          />
                        </div>
                        <span className="font-medium">{checker.name}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {checker.count !== undefined && checker.count > 0 && (
                          <Badge 
                            variant="outline" 
                            className="text-xs font-mono px-1.5 py-0"
                            data-testid={`badge-count-${checker.name.toLowerCase()}`}
                          >
                            {checker.count > 999 ? `${Math.floor(checker.count / 1000)}k` : checker.count}
                          </Badge>
                        )}
                      </div>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      
      <SidebarFooter className="border-t">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton data-testid="button-user-profile">
              <User className="w-4 h-4" />
              <span>Profile</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <LogoutButton />
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}