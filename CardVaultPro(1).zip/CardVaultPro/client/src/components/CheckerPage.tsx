import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import CardVerificationTable from "@/components/CardVerificationTable";
import { Play, Pause, Square, Upload, Settings, BarChart3, Download } from "lucide-react";
import { ReactElement } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface CheckerPageProps {
  name: string;
  description: string;
  icon: ReactElement;
  color: string;
  features: string[];
  defaultConfig: Record<string, any>;
}

export default function CheckerPage({ name, description, icon, color, features, defaultConfig }: CheckerPageProps) {
  const [status, setStatus] = useState<'idle' | 'running' | 'paused' | 'completed'>('idle');
  const [progress, setProgress] = useState(0);
  const [cardData, setCardData] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [config, setConfig] = useState(defaultConfig);
  const [stats, setStats] = useState({ total: 0, valid: 0, invalid: 0, pending: 0 });
  const [processedCards, setProcessedCards] = useState<any[]>([]);
  const [cardQueue, setCardQueue] = useState<string[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pausedProgressRef = useRef<number>(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Basic Luhn algorithm for card number validation
  const isValidCardNumber = (cardNumber: string) => {
    const cleanedNumber = cardNumber.replace(/\D/g, '');
    if (cleanedNumber.length < 13 || cleanedNumber.length > 19) return false;
    
    let sum = 0;
    let isEvenIndex = false;
    
    for (let i = cleanedNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cleanedNumber.charAt(i));
      
      if (isEvenIndex) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      
      sum += digit;
      isEvenIndex = !isEvenIndex;
    }
    
    return sum % 10 === 0;
  };

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (data: { name: string; checkerType: string }) => {
      const response = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Failed to create session');
      return response.json();
    }
  });

  const handleStart = async () => {
    if (!cardData && !file) {
      toast({
        title: "No Data Provided",
        description: "Please provide card data either by uploading a file or pasting data",
        variant: "destructive"
      });
      return;
    }
    
    if (status === 'paused') {
      // Resume from where we paused
      setStatus('running');
      startProcessing();
      return;
    }
    
    // Fresh start - reset everything
    const cards = cardData.split('\n').filter(line => line.trim());
    setCardQueue(cards);
    setProcessedCards([]);
    setProgress(0);
    pausedProgressRef.current = 0;
    setStats({ total: cards.length, valid: 0, invalid: 0, pending: cards.length });
    setStatus('running');
    startProcessing();
  };
  
  const startProcessing = () => {
    const speedMs = config.speed === 'fast' ? 50 : config.speed === 'slow' ? 200 : 100;
    
    intervalRef.current = setInterval(() => {
      setCardQueue(prevQueue => {
        if (prevQueue.length === 0) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
          }
          setStatus('completed');
          setProgress(100);
          return prevQueue;
        }
        
        const batchSize = Math.min(config.batchSize || 100, prevQueue.length);
        const batch = prevQueue.slice(0, batchSize);
        const remaining = prevQueue.slice(batchSize);
        
        // Process results using real validation logic (simplified)
        const newResults = batch.map((card, idx) => {
          const cardParts = card.split('|');
          const cardNumber = cardParts[0] || card.substring(0, 16);
          const expMonth = cardParts[1] || '12';
          const expYear = cardParts[2] || '25';
          // Use basic Luhn algorithm for card validation instead of Math.random
          const isValid = isValidCardNumber(cardNumber);
          
          return {
            id: (Date.now() + idx).toString(),
            cardNumber: cardNumber.substring(0, 4) + '************' + cardNumber.slice(-4),
            expiryMonth: expMonth,
            expiryYear: expYear,
            cvv: '***',
            status: (isValid ? 'LIVE' : 'DEAD') as 'LIVE' | 'DEAD' | 'PENDING' | 'ERROR',
            response: isValid ? 'Approved - Valid card' : 'Declined - Invalid card',
            checker: name,
            timestamp: new Date().toLocaleString(),
            processingTime: Math.floor(Math.random() * 3000) + 500
          };
        });
        
        setProcessedCards(prev => [...prev, ...newResults]);
        
        const validCount = newResults.filter(r => r.status === 'LIVE').length;
        const invalidCount = newResults.filter(r => r.status === 'DEAD').length;
        
        setStats(prev => ({
          ...prev,
          valid: prev.valid + validCount,
          invalid: prev.invalid + invalidCount,
          pending: remaining.length
        }));
        
        const totalProcessed = stats.total - remaining.length;
        const newProgress = (totalProcessed / stats.total) * 100;
        setProgress(newProgress);
        
        return remaining;
      });
    }, speedMs);
  };

  const handlePause = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    pausedProgressRef.current = progress;
    setStatus('paused');
  };

  const handleStop = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setStatus('idle');
    setProgress(0);
    pausedProgressRef.current = 0;
    setProcessedCards([]);
    setCardQueue([]);
    setStats({ total: 0, valid: 0, invalid: 0, pending: 0 });
  };
  
  const handleExport = () => {
    if (processedCards.length === 0) return;
    
    const csvContent = [
      'Card Number,Expiry Month,Expiry Year,Status,Response,Checker,Timestamp,Processing Time (ms)',
      ...processedCards.map(card => 
        `"${card.cardNumber}","${card.expiryMonth}","${card.expiryYear}","${card.status}","${card.response}","${card.checker}","${card.timestamp}","${card.processingTime}"`
      )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${name}_results_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Cleanup interval on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && (file.type === 'text/csv' || file.type === 'text/plain' || file.name.endsWith('.txt'))) {
      setFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        setCardData(text);
        const lines = text.split('\n').filter(line => line.trim());
        setStats(prev => ({ ...prev, total: lines.length, pending: lines.length }));
      };
      reader.readAsText(file);
    }
  };

  const handleTextareaChange = (value: string) => {
    setCardData(value);
    const lines = value.split('\n').filter(line => line.trim());
    setStats(prev => ({ ...prev, total: lines.length, pending: lines.length }));
  };

  return (
    <div className="p-6 space-y-8" data-testid={`page-checker-${name.toLowerCase()}`}>
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-lg ${color}`}>
            {icon}
          </div>
          <div>
            <h1 className="text-3xl font-bold">{name} Checker</h1>
            <p className="text-muted-foreground mt-1">{description}</p>
            <div className="flex flex-wrap gap-2 mt-2">
              {features.map((feature, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {feature}
                </Badge>
              ))}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge 
            className={`capitalize ${
              status === 'running' ? 'bg-chart-2 text-white' :
              status === 'paused' ? 'bg-chart-4 text-white' :
              status === 'completed' ? 'bg-chart-1 text-white' :
              'bg-muted text-muted-foreground'
            }`}
            data-testid={`status-${name.toLowerCase()}`}
          >
            {status}
          </Badge>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold font-mono" data-testid={`stat-total-${name.toLowerCase()}`}>
              {stats.total.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Total Cards</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold font-mono text-chart-2" data-testid={`stat-valid-${name.toLowerCase()}`}>
              {stats.valid.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Valid (VIVA)</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold font-mono text-destructive" data-testid={`stat-invalid-${name.toLowerCase()}`}>
              {stats.invalid.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Invalid (MUERTA)</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold font-mono text-chart-4" data-testid={`stat-pending-${name.toLowerCase()}`}>
              {stats.pending.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Pending</div>
          </CardContent>
        </Card>
      </div>

      {/* Progress */}
      {(status === 'running' || status === 'paused') && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Processing Progress</span>
              <span className="text-sm text-muted-foreground">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 space-y-6">
          {/* Data Input */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Card Data Input
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="paste" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="paste">Paste Data</TabsTrigger>
                  <TabsTrigger value="upload">Upload File</TabsTrigger>
                </TabsList>
                
                <TabsContent value="paste" className="space-y-4">
                  <div>
                    <Label htmlFor="cardData">Credit Card Data</Label>
                    <Textarea
                      id="cardData"
                      placeholder="Paste your credit card data here...\nFormat: cardnumber|mm|yy|cvv\nExample: 4111111111111111|12|25|123"
                      className="min-h-32 font-mono text-sm"
                      value={cardData}
                      onChange={(e) => handleTextareaChange(e.target.value)}
                      data-testid={`input-card-data-${name.toLowerCase()}`}
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="upload" className="space-y-4">
                  <div>
                    <Label htmlFor="file">Upload CSV/TXT File</Label>
                    <Input
                      id="file"
                      type="file"
                      accept=".csv,.txt"
                      onChange={handleFileChange}
                      data-testid={`input-file-${name.toLowerCase()}`}
                    />
                    {file && (
                      <p className="text-sm text-muted-foreground mt-2">
                        Selected: {file.name} ({(file.size / 1024).toFixed(1)} KB)
                      </p>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Controls */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-center gap-4">
                {status === 'idle' || status === 'paused' ? (
                  <Button 
                    onClick={handleStart}
                    className="px-8"
                    data-testid={`button-start-${name.toLowerCase()}`}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {status === 'paused' ? 'Resume' : 'Start Processing'}
                  </Button>
                ) : (
                  <Button 
                    onClick={handlePause}
                    variant="outline"
                    className="px-8"
                    data-testid={`button-pause-${name.toLowerCase()}`}
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </Button>
                )}
                
                {status !== 'idle' && (
                  <Button 
                    onClick={handleStop}
                    variant="destructive"
                    className="px-8"
                    data-testid={`button-stop-${name.toLowerCase()}`}
                  >
                    <Square className="w-4 h-4 mr-2" />
                    Stop
                  </Button>
                )}

                {status === 'completed' && (
                  <Button 
                    onClick={handleExport}
                    variant="outline"
                    className="px-8"
                    data-testid={`button-export-${name.toLowerCase()}`}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export Results
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Configuration */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <Label>Processing Speed</Label>
                  <Select 
                    value={config.speed}
                    onValueChange={(value) => setConfig(prev => ({ ...prev, speed: value }))}
                  >
                    <SelectTrigger data-testid={`select-speed-${name.toLowerCase()}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="slow">Slow (Safer)</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="fast">Fast</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>Batch Size</Label>
                  <Input 
                    type="number" 
                    value={config.batchSize}
                    onChange={(e) => setConfig(prev => ({ ...prev, batchSize: parseInt(e.target.value) || 100 }))}
                    min="1" 
                    max="1000"
                    data-testid={`input-batch-size-${name.toLowerCase()}`}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label>Skip Invalid Format</Label>
                  <Switch 
                    checked={config.skipInvalid}
                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, skipInvalid: checked }))}
                    data-testid={`switch-skip-invalid-${name.toLowerCase()}`} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label>Auto Retry</Label>
                  <Switch 
                    checked={config.autoRetry}
                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, autoRetry: checked }))}
                    data-testid={`switch-auto-retry-${name.toLowerCase()}`} 
                  />
                </div>
                
                <div>
                  <Label>Timeout (seconds)</Label>
                  <Input 
                    type="number" 
                    value={config.timeout}
                    onChange={(e) => setConfig(prev => ({ ...prev, timeout: parseInt(e.target.value) || 30 }))}
                    min="5" 
                    max="300"
                    data-testid={`input-timeout-${name.toLowerCase()}`}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Results */}
      {(status === 'running' || status === 'completed' || status === 'paused') && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Live Results</h2>
            <Button variant="outline" size="sm">
              <BarChart3 className="w-4 h-4 mr-2" />
              View Analytics
            </Button>
          </div>
          <CardVerificationTable 
            results={processedCards}
            title={`${name} Processing Results`}
            showFilters={true}
            onExport={handleExport}
          />
        </div>
      )}
    </div>
  );
}