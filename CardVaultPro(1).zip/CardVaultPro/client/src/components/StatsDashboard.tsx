import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Activity, DollarSign, Users, Shield, CreditCard } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface StatItemProps {
  title: string;
  value: string;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  icon: React.ReactNode;
}

function StatItem({ title, value, change, trend = 'neutral', icon }: StatItemProps) {
  const getTrendColor = () => {
    switch (trend) {
      case 'up': return 'text-chart-2';
      case 'down': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const getTrendIcon = () => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-3 h-3" />;
      case 'down': return <TrendingDown className="w-3 h-3" />;
      default: return null;
    }
  };

  return (
    <Card className="hover-elevate" data-testid={`card-stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className="text-primary">
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold font-mono" data-testid={`text-stat-value-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {value}
        </div>
        {change && (
          <div className={`flex items-center gap-1 text-xs mt-1 ${getTrendColor()}`}>
            {getTrendIcon()}
            <span data-testid={`text-stat-change-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {change}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface UserStats {
  totalSessions: number;
  totalCards: number;
  totalValid: number;
  totalInvalid: number;
  totalErrors: number;
  successRate: number;
}

export default function StatsDashboard() {
  const { data: stats, isLoading, error } = useQuery<UserStats>({
    queryKey: ['/api/stats'],
    retry: 1
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} className="hover-elevate">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-4 rounded" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-16 mb-2" />
              <Skeleton className="h-3 w-24" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <Card className="col-span-full">
          <CardContent className="pt-6">
            <p className="text-destructive text-center">Failed to load statistics</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const {
    totalSessions = 0,
    totalCards = 0,
    totalValid = 0,
    totalInvalid = 0,
    totalErrors = 0,
    successRate = 0
  } = stats || {};
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      <StatItem
        title="Total Sessions"
        value={totalSessions.toLocaleString()}
        icon={<Activity className="w-4 h-4" />}
      />
      
      <StatItem
        title="Total Cards"
        value={totalCards.toLocaleString()}
        icon={<CreditCard className="w-4 h-4" />}
      />
      
      <StatItem
        title="Valid Cards"
        value={totalValid.toLocaleString()}
        trend="up"
        icon={<Shield className="w-4 h-4" />}
      />
      
      <StatItem
        title="Invalid Cards"
        value={totalInvalid.toLocaleString()}
        trend="down"
        icon={<TrendingDown className="w-4 h-4" />}
      />
      
      <StatItem
        title="Errors"
        value={totalErrors.toLocaleString()}
        icon={<Activity className="w-4 h-4" />}
      />
      
      <StatItem
        title="Success Rate"
        value={`${successRate.toFixed(1)}%`}
        trend={successRate > 50 ? "up" : successRate < 30 ? "down" : "neutral"}
        icon={<TrendingUp className="w-4 h-4" />}
      />
    </div>
  );
}