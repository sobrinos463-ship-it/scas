import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Play, Pause, Settings, BarChart3 } from "lucide-react";
import { useState } from "react";

interface CheckerStats {
  total: number;
  valid: number;
  invalid: number;
  pending: number;
}

interface CheckerCardProps {
  name: string;
  description: string;
  icon: React.ReactNode;
  status: 'idle' | 'running' | 'paused' | 'completed';
  stats: CheckerStats;
  progress?: number;
  onStart: () => void;
  onPause: () => void;
  onConfigure: () => void;
  onViewResults: () => void;
}

export default function CheckerCard({
  name,
  description,
  icon,
  status,
  stats,
  progress = 0,
  onStart,
  onPause,
  onConfigure,
  onViewResults
}: CheckerCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const getStatusColor = () => {
    switch (status) {
      case 'running': return 'bg-chart-2 text-white';
      case 'paused': return 'bg-chart-4 text-white';
      case 'completed': return 'bg-primary text-primary-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'running': return 'RUNNING';
      case 'paused': return 'PAUSED';
      case 'completed': return 'COMPLETED';
      default: return 'IDLE';
    }
  };

  return (
    <Card 
      className="hover-elevate cursor-pointer transition-all duration-200" 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      data-testid={`card-checker-${name.toLowerCase()}`}
    >
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              {icon}
            </div>
            <div>
              <CardTitle className="text-lg font-semibold" data-testid={`text-checker-name-${name.toLowerCase()}`}>
                {name}
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">{description}</p>
            </div>
          </div>
          <Badge className={`${getStatusColor()} font-mono text-xs`} data-testid={`badge-status-${name.toLowerCase()}`}>
            {getStatusText()}
          </Badge>
        </div>
        
        {status === 'running' && (
          <div className="mt-4 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-mono font-medium" data-testid={`text-progress-${name.toLowerCase()}`}>{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" data-testid={`progress-${name.toLowerCase()}`} />
          </div>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="space-y-1">
            <div className="text-muted-foreground">Total</div>
            <div className="font-mono font-bold text-lg" data-testid={`text-total-${name.toLowerCase()}`}>
              {stats.total.toLocaleString()}
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-muted-foreground">Pending</div>
            <div className="font-mono font-bold text-lg text-chart-4" data-testid={`text-pending-${name.toLowerCase()}`}>
              {stats.pending.toLocaleString()}
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-muted-foreground">Valid</div>
            <div className="font-mono font-bold text-lg text-chart-2" data-testid={`text-valid-${name.toLowerCase()}`}>
              {stats.valid.toLocaleString()}
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-muted-foreground">Invalid</div>
            <div className="font-mono font-bold text-lg text-destructive" data-testid={`text-invalid-${name.toLowerCase()}`}>
              {stats.invalid.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-2">
          {status === 'running' ? (
            <Button 
              size="sm" 
              variant="secondary" 
              onClick={onPause}
              className="flex-1"
              data-testid={`button-pause-${name.toLowerCase()}`}
            >
              <Pause className="w-4 h-4 mr-2" />
              Pause
            </Button>
          ) : (
            <Button 
              size="sm" 
              onClick={onStart}
              className="flex-1"
              data-testid={`button-start-${name.toLowerCase()}`}
            >
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
          )}
          
          <Button 
            size="sm" 
            variant="outline" 
            onClick={onConfigure}
            data-testid={`button-configure-${name.toLowerCase()}`}
          >
            <Settings className="w-4 h-4" />
          </Button>
          
          <Button 
            size="sm" 
            variant="outline" 
            onClick={onViewResults}
            data-testid={`button-results-${name.toLowerCase()}`}
          >
            <BarChart3 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}