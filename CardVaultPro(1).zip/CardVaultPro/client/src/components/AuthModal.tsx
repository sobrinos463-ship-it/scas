import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Shield, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface AuthModalProps {
  trigger?: React.ReactNode;
  onAuthSuccess?: (user: any) => void;
}

export default function AuthModal({ trigger, onAuthSuccess }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ 
    username: '', 
    password: '', 
    confirmPassword: '' 
  });
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const loginMutation = useMutation({
    mutationFn: async (data: { username: string; password: string }) => {
      const response = await fetch('/api/login', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Login failed');
      }
      
      return response.json();
    },
    onSuccess: (user) => {
      toast({ 
        title: "Welcome back!", 
        description: `Successfully logged in as ${user.username}` 
      });
      queryClient.invalidateQueries();
      setOpen(false);
      setFormData({ username: '', password: '', confirmPassword: '' });
      onAuthSuccess?.(user);
    },
    onError: (error: any) => {
      toast({ 
        title: "Login failed", 
        description: error.message || "Invalid username or password",
        variant: "destructive" 
      });
    }
  });

  const registerMutation = useMutation({
    mutationFn: async (data: { username: string; password: string }) => {
      const response = await fetch('/api/register', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Registration failed');
      }
      
      return response.json();
    },
    onSuccess: (user) => {
      toast({ 
        title: "Account created!", 
        description: `Welcome ${user.username}! You're now logged in.` 
      });
      queryClient.invalidateQueries();
      setOpen(false);
      setFormData({ username: '', password: '', confirmPassword: '' });
      onAuthSuccess?.(user);
    },
    onError: (error: any) => {
      toast({ 
        title: "Registration failed", 
        description: error.message || "Unable to create account",
        variant: "destructive" 
      });
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isLogin && formData.password !== formData.confirmPassword) {
      toast({
        title: "Password mismatch",
        description: "Passwords do not match",
        variant: "destructive"
      });
      return;
    }

    const data = {
      username: formData.username,
      password: formData.password
    };

    if (isLogin) {
      loginMutation.mutate(data);
    } else {
      registerMutation.mutate(data);
    }
  };

  const isLoading = loginMutation.isPending || registerMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || <Button data-testid="button-open-auth">Login</Button>}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Shield className="w-6 h-6 text-primary" />
            <DialogTitle>CreditCheck Pro</DialogTitle>
          </div>
          <DialogDescription>
            {isLogin 
              ? "Sign in to access your dashboard" 
              : "Create account to get started"
            }
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex gap-2">
            <Button 
              variant={isLogin ? "default" : "outline"} 
              size="sm" 
              className="flex-1"
              onClick={() => setIsLogin(true)}
              data-testid="button-tab-login"
            >
              Login
            </Button>
            <Button 
              variant={!isLogin ? "default" : "outline"} 
              size="sm" 
              className="flex-1"
              onClick={() => setIsLogin(false)}
              data-testid="button-tab-register"
            >
              Register
            </Button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="modal-username">Username</Label>
              <Input
                id="modal-username"
                type="text"
                placeholder={isLogin ? "Enter username" : "Choose username"}
                value={formData.username}
                onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                required
                data-testid="input-modal-username"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="modal-password">Password</Label>
              <Input
                id="modal-password"
                type="password"
                placeholder={isLogin ? "Enter password" : "Create password"}
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                required
                data-testid="input-modal-password"
              />
            </div>
            
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="modal-confirm-password">Confirm Password</Label>
                <Input
                  id="modal-confirm-password"
                  type="password"
                  placeholder="Confirm password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  required
                  data-testid="input-modal-confirm-password"
                />
              </div>
            )}
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isLoading}
              data-testid="button-modal-submit"
            >
              {isLoading 
                ? (isLogin ? "Signing in..." : "Creating account...") 
                : (isLogin ? "Sign in" : "Create account")
              }
            </Button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}