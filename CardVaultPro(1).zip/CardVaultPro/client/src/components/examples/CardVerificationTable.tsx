import CardVerificationTable from '../CardVerificationTable';

export default function CardVerificationTableExample() {
  return (
    <div className="p-6">
      <CardVerificationTable />
    </div>
  );
}