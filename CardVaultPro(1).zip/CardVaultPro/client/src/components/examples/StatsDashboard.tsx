import StatsDashboard from '../StatsDashboard';

export default function StatsDashboardExample() {
  return (
    <div className="p-6">
      <StatsDashboard />
    </div>
  );
}