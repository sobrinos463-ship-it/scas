import BulkUploadForm from '../BulkUploadForm';

export default function BulkUploadFormExample() {
  return (
    <div className="p-6">
      <BulkUploadForm />
    </div>
  );
}