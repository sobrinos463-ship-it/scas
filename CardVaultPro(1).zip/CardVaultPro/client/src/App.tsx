import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Button } from "@/components/ui/button";
import { Sun, Moon as MoonIcon, User, LogOut, Shield } from "lucide-react";
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import AuthModal from "@/components/AuthModal";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Upload from "@/pages/Upload";
import Results from "@/pages/Results";
import Luna from "@/pages/checkers/Luna";
import Orio from "@/pages/checkers/Orio";
import Ady from "@/pages/checkers/Ady";
import Manzana from "@/pages/checkers/Manzana";
import Stritt from "@/pages/checkers/Stritt";

function ThemeToggle() {
  const [isDark, setIsDark] = useState(() => {
    // Check localStorage first, then system preference
    const saved = localStorage.getItem('theme');
    if (saved) {
      return saved === 'dark';
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setIsDark(!isDark)}
      data-testid="button-theme-toggle"
    >
      {isDark ? (
        <Sun className="w-4 h-4" />
      ) : (
        <MoonIcon className="w-4 h-4" />
      )}
    </Button>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/upload" component={Upload} />
      <Route path="/results" component={Results} />
      <Route path="/history" component={() => <div className="p-6"><h1 className="text-3xl font-bold">History</h1><p className="text-muted-foreground mt-2">View your verification history and past operations.</p></div>} />
      <Route path="/settings" component={() => <div className="p-6"><h1 className="text-3xl font-bold">Settings</h1><p className="text-muted-foreground mt-2">Configure your checkers and platform preferences.</p></div>} />
      <Route path="/checker/luna" component={Luna} />
      <Route path="/checker/orio" component={Orio} />
      <Route path="/checker/ady" component={Ady} />
      <Route path="/checker/manzana" component={Manzana} />
      <Route path="/checker/stritt" component={Stritt} />
      <Route component={NotFound} />
    </Switch>
  );
}

function UserArea() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: user, isLoading: userLoading } = useQuery<{id: string; username: string; createdAt: string}>({
    queryKey: ['/api/user'],
    retry: false
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/logout', { method: 'POST' });
      if (!response.ok) throw new Error('Logout failed');
    },
    onSuccess: () => {
      queryClient.setQueryData(['/api/user'], null);
      queryClient.clear();
      toast({
        title: "Logged out",
        description: "Successfully logged out"
      });
    }
  });

  if (userLoading) {
    return <div className="w-8 h-8 animate-pulse bg-muted rounded" />;
  }

  if (user) {
    return (
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-2 text-sm">
          <User className="w-4 h-4" />
          <span>{user.username}</span>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => logoutMutation.mutate()}
          disabled={logoutMutation.isPending}
          data-testid="button-logout"
        >
          <LogOut className="w-4 h-4" />
          {logoutMutation.isPending ? "..." : "Logout"}
        </Button>
      </div>
    );
  }

  return (
    <AuthModal 
      trigger={
        <Button 
          variant="outline" 
          size="sm"
          data-testid="button-open-login"
        >
          Login
        </Button>
      }
      onAuthSuccess={() => {
        queryClient.invalidateQueries();
      }}
    />
  );
}

function ProtectedApp() {
  const { data: user, isLoading } = useQuery({
    queryKey: ['/api/user'],
    retry: false
  });

  // Show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 animate-spin border-2 border-primary border-t-transparent rounded-full mx-auto" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Show login screen if not authenticated
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="w-full max-w-md space-y-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">CreditCheck Pro</h1>
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-semibold">Authentication Required</h2>
            <p className="text-muted-foreground">Please sign in to access the professional card verification platform</p>
          </div>
          <AuthModal 
            trigger={
              <Button size="lg" className="w-full" data-testid="button-login-required">
                Sign In / Register
              </Button>
            }
            onAuthSuccess={() => {
              // Authentication successful, the component will re-render
            }}
          />
          <div className="flex items-center justify-center gap-2 mt-4">
            <ThemeToggle />
          </div>
        </div>
      </div>
    );
  }

  // User is authenticated, show the main app
  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1">
          <header className="flex items-center justify-between p-4 border-b bg-card">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div className="hidden sm:block">
                <h1 className="font-semibold text-lg">CreditCheck Pro</h1>
                <p className="text-xs text-muted-foreground">Professional Card Verification Platform</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <UserArea />
            </div>
          </header>
          <main className="flex-1 overflow-auto bg-background">
            <Router />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ProtectedApp />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
